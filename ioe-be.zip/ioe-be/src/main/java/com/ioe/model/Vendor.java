package com.ioe.model;

import lombok.Data;

import java.util.List;

@Data
public class Vendor {
    private String vendorId;
    private String businessName;
    private String location;
    private String businessMobileNumber;
    private String businessEmailAddress;
    private String vendorStatus;
    private Integer isActive;
    private String createdTs;
    private List<VendorService> services;
}
