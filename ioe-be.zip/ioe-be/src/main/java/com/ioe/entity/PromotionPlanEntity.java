package com.ioe.entity;

import lombok.Data;
import org.aspectj.weaver.loadtime.definition.Definition;

import javax.persistence.*;

@Entity
@Data
@Table(name = "ioe_promotion_plans")
public class PromotionPlanEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer planId;
    private String productId;
    private String organizationId;
    private String planCode;
    private String planName;
    private Float planAmount;
    private Float taxAmount;
    private Integer planDuration;
}
