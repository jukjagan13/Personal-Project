package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "ioe_vendor_service_promotions")
@Data
public class VendorServicePromotionEntity {
    @Id
    private String promotionId;
    private String vendorId;
    private String serviceId;
    private String planCode;
    private String status;
    private Timestamp promotionStartDate;
    private Timestamp promotionEndDate;
    private Float planAmount;
    private Float taxAmount;
    private String providerReferenceId;
    private String providerOrderId;
    private String providerPaymentId;
    private String createdTs;
    private String lastUpdatedTs;
}
