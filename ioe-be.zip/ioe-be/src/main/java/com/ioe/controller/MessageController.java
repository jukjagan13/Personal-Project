//package com.ioe.controller;
//
//import com.ioe.model.Message;
//import com.ioe.model.Response;
//import com.ioe.service.MessageService;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("message")
//@Slf4j
//public class MessageController {
//    @Autowired
//    private MessageService messageService;
//
//    @PostMapping("send")
//    public Response sendMessage(@RequestBody Message message) {
//        return messageService.sendMessage(message);
//    }
//
//    @GetMapping("list")
//    public Response getMessage() {
//        return messageService.getMessagesList();
//    }
//
//    @GetMapping()
//    public Response getMessage(@RequestParam(name="sender") String senderId) {
//        return messageService.getMessages(senderId);
//    }
//
//    @PostMapping("mark-read")
//    public Response markRead(@RequestParam(name="sender", required = false) String senderId) {
//        return messageService.markReadMessages(senderId);
//    }
//
//    @GetMapping("notification")
//    public Response getUnReadMessageCount() {
//        return messageService.getNotificationCount();
//    }
//}