package com.ioe.model;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

import java.util.List;

@Data
public class VendorServiceMini {
    private String serviceId;
    private String vendorId;
    private String serviceType;
    private String serviceName;
    private JsonNode address;
    private List<ServiceAttribute> highlightedAttributes;
    private String branchLocation;
    private String serviceLogoId;
    private Asset serviceLogo;
    private Integer isPromoted;
}
