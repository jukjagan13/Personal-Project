package com.ioe.repository;

import com.ioe.entity.PromotionPlanEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PromotionPlanRepository extends JpaRepository<PromotionPlanEntity, Integer> {

    PromotionPlanEntity findByPlanCode(String planCode);

}
