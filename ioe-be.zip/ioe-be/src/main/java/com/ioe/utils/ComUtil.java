package com.ioe.utils;

import com.ioe.model.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

@Component
@Slf4j
public class ComUtil {

    public static final Response response(String code, String message, Object data) {
        Response response = new Response();
        response.setCode(code);
        response.setMessage(message);
        response.setData(data);
        return response;
    }

    public static final String content(MessageSource messageSource, String source, Object[] objects) {
        return messageSource.getMessage(source, objects, Locale.getDefault());
    }

    public static String maskEmail(String email) {
        String name = email.split("@")[0];
        String domain = email.split("@")[1];
        String maskedEmail = email;
//        String maskedEmail = email.replaceAll("(^[^@]{3}|(?!^)\\G)[^@]", "$1*");
        if (name.length() > 2) {
            maskedEmail = name.substring(0, 2) + "XXXX@" + domain;
        }
        return maskedEmail.toUpperCase();
    }

    public static String maskMobileNumber(String mobileNumber) {
        String maskedMobile;
        if (mobileNumber != null) {
            String mobNum = mobileNumber.replace("-", "");
            String maskStr = "";
            int mobLen = mobNum.length();
            while (maskStr.length() + 6 != mobLen) {
                maskStr += "X";
            }
            maskedMobile = mobNum.substring(0, 5) + maskStr + mobNum.substring(mobLen - 2, mobLen);
        } else {
            maskedMobile = "";
        }
        return maskedMobile;
    }

//    public static String getRandomNumber(int digCount) {
//        Random rnd = new Random();
//        StringBuilder sb = new StringBuilder(digCount);
//        for(int i=0; i < digCount; i++)
//            sb.append((char)('0' + rnd.nextInt(10)));
//        return sb.toString();
//    }

    public static Date convertStringToDate(String date) {
        Date date1 = null;
        try {
            date1 = new SimpleDateFormat("dd-MM-yyyy").parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date1;
    }

    public static String addDaysToDate(Date date, Integer noOfDaysToAdd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, noOfDaysToAdd);
        String res = convertDateToString(cal.getTime());
        return res;
    }

    public static String convertDateToString(Date dateFormat) {
        String date;
        String pattern = "dd-MM-yyyy";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        date = simpleDateFormat.format(dateFormat);
        return date;
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}
