package com.ioe.model;

import lombok.Data;

@Data
public class UserReview {
    private String name;
    private String email;
    private String review;
}
