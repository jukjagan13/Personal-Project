package com.ioe.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Asset {
    @JsonProperty("assetId")
    private String id;
    @JsonProperty("assetExtension")
    private String contentType;
    @JsonProperty("assetData")
    private String data;
}
