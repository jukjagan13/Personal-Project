package com.ioe.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.MessageDigest;
import java.security.SignatureException;
import java.util.Arrays;
import java.util.Base64;

@Component
@Slf4j
public class CryptoUtil {
    private static final String HMAC_SHA256_ALGORITHM = "HmacSHA256";

    public static String hashStringSHA26(String str) {
        log.info("---- hashPasswordSHA26 for {} ----", str);
        String finStr = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(str.getBytes(StandardCharsets.UTF_8));
            BigInteger number = new BigInteger(1, hash);
            StringBuilder stringBuilder = new StringBuilder(number.toString(16));
            if (stringBuilder.length() < 32) {
                stringBuilder.insert(0, '0');
            }
            finStr = stringBuilder.toString();
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }
        log.info("---- hashPasswordSHA26 hashed str {} ----", finStr);
        return finStr;
    }

    public static String hashStringBCrypt(String str) {
        String finStr = null;
        try {
            System.out.println(BCrypt.gensalt());
            finStr = BCrypt.hashpw(str, BCrypt.gensalt());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finStr;
    }

    public static String hashUUID(String str) {
        log.info("---- hashUUID for {} ----", str);
        String finStr = null;
        try {
            finStr = BCrypt.hashpw(str, BCrypt.gensalt());
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
        }
        log.info("---- hashUUID hashed str {} ----", finStr);
        return finStr;
    }

    public static String aesEncrypt(String toEncrypt, String secret){
        try {
        byte[] decoded = Base64.getDecoder().decode(secret.getBytes());
        Key key = new SecretKeySpec(decoded, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = cipher.doFinal(toEncrypt.getBytes());
        String encryptedValue = Base64.getEncoder().encodeToString(encVal);
        return encryptedValue;
        } catch (Exception e) {
            System.out.println("Error while encrypting: " + e.toString());
        }
        return null;
    }

    public static String aesDecrypt(String strToDecrypt, String secret) {
        try {
            byte[] decoded = Base64.getDecoder().decode(secret.getBytes());
            Key key = new SecretKeySpec(decoded, "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }

//    public boolean comparePasswordSHA26(String str, String hashedStr) {
//        log.info("---- comparePasswordSHA26 for orginal {} & reqested {} ----", hashedStr, str);
//        boolean validationResult = false;
//        try {
//            String newHashedStr = hashPasswordSHA26(str);
//            if(newHashedStr.equals(hashedStr)) {
//                validationResult = true;
//            }
//        } catch (Exception e) {
//            validationResult = false;
//            e.printStackTrace();
//            log.error(e.getMessage());
//        }
//        log.info("---- comparePasswordSHA26 comparing result matching {} ----", validationResult);
//        return validationResult;
//    }

    public static String calculateRFC2104HMAC(String data, String secret) throws SignatureException {
        String result;
        try {
            // get an hmac_sha256 key from the raw secret bytes
            SecretKeySpec signingKey = new SecretKeySpec(secret.getBytes(), HMAC_SHA256_ALGORITHM);
            // get an hmac_sha256 Mac instance and initialize with the signing key
            Mac mac = Mac.getInstance(HMAC_SHA256_ALGORITHM);
            mac.init(signingKey);
            // compute the hmac on input data bytes
            byte[] rawHmac = mac.doFinal(data.getBytes());
            // base64-encode the hmac
            result = DatatypeConverter.printHexBinary(rawHmac).toLowerCase();
        } catch (Exception e) {
            throw new SignatureException("Failed to generate HMAC : " + e.getMessage());
        }
        return result;
    }

    /*
    Fixme: To Be Deleted
     */
    public static String generateAESKey() {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            SecretKey newSecretKey = keyGenerator.generateKey();
            String encoded = Arrays.toString(newSecretKey.getEncoded());
            String encodedKey = Base64.getEncoder().encodeToString(newSecretKey.getEncoded());
            System.out.println(encodedKey);
            return encodedKey;
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
