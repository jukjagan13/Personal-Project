package com.ioe.exception;

import com.ioe.model.Response;
import lombok.extern.slf4j.Slf4j;
import lombok.*;
import org.hibernate.type.ObjectType;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

//import org.springframework.security.access.AccessDeniedException;

@RestControllerAdvice
@Slf4j
public class AppExceptionHandler {

    @ExceptionHandler(value = {ValidationException.class})
    @ResponseStatus(HttpStatus.EXPECTATION_FAILED)
    public ErrorResponse validationExceptionHandler(ValidationException ex) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.EXPECTATION_FAILED.value(), ex.getValidationErrors().get(0).getDefaultMessage(), ex.getValidationErrors().get(0).getCode());
        log.error("Validation Error", ex);
        return errorResponse;
    }

//    @ExceptionHandler(value = { AccessDeniedException.class })
//    @ResponseStatus(HttpStatus.FORBIDDEN)
//    public ErrorResponse accessDeniedExceptionHandler(AccessDeniedException ex)
//    {
//        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.FORBIDDEN.value(),"Access Denied. Not Authorized","");
//        log.error("Authorization Denied",ex);
//        return errorResponse;
//    }

    @ExceptionHandler(value = {ResourceNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse uncaughtResourceNotFoundExceptionHandler(ResourceNotFoundException ex) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getResourceName() + " not found for " + ex.getResourceValue(), "");
        log.error("Server Error", ex);
        return errorResponse;
    }

    @ExceptionHandler(value = {JwtException.class})
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ErrorResponse JwtExceptionHandler(JwtException ex) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.FORBIDDEN.value(), ex.getMessage(), "");
        log.error("Authorization Error", ex);
        return errorResponse;
    }

    @ExceptionHandler(value = {AuthorizationException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ErrorResponse AuthorizationExceptionHandler(AuthorizationException ex) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), ex.getMessage(), "");
        log.error("Authorization Error", ex);
        return errorResponse;
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse uncaughtExceptionHandler(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage(), "");
        log.error("Server Error", ex);
        return errorResponse;
    }
}
