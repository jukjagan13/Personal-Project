package com.ioe.repository;

import com.ioe.entity.UserEntity;
import com.ioe.entity.VerificationCodesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;

@Repository
public interface VerificationCodesRepository extends JpaRepository<VerificationCodesEntity, Integer> {

    VerificationCodesEntity findBySession(String session);

    VerificationCodesEntity findBySessionAndCode(String session, Integer code);

    @Query("from VerificationCodesEntity where session = ?1 and code = ?2 and provided_ts < ?3 and expiration_ts >= ?3 and no_of_tries < 3")
    VerificationCodesEntity findBySessionAndCodeAndActive(String session, Integer code, Timestamp currentTs);

}
