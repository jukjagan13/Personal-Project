package com.ioe.model;

import lombok.Data;

import javax.validation.constraints.Email;

@Data
public class SignUpRequest {
    private String username;
    private String userType;
    private String mobile;
    @Email(message = "Email should be valid")
    private String email;
    private String location;
    private String key;
}
