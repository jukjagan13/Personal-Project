import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-group-restricted-home',
  templateUrl: './group-restricted-home.component.html',
  styleUrls: ['./group-restricted-home.component.css']
})
export class GroupRestrictedHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
