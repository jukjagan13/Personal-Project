//package com.ioe.exception;
//
//import com.sun.mail.iap.Response;
//import com.sun.mail.iap.ResponseHandler;
//
//public class AppResponseHandler implements ResponseHandler<String> {
//    @Override
//    public void handleResponse(ClassicHttpResponse  response) {
//
//    }
//}
