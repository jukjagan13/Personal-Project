package com.ioe.model;

import lombok.Data;

@Data
public class Message {
    private String senderId;
    private String receiverId;
    private String messageContent;
    private Integer isRead;
    private String messagedTs;
}
