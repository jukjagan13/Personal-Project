package com.ioe.model;

import lombok.Data;

import javax.validation.constraints.Email;

@Data
public class SignInRequest {
    @Email(message = "Email should be valid")
    private String id;
    private String key;
}
