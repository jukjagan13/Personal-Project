package com.ioe.service;

import com.ioe.entity.MasterDataEntity;
import com.ioe.entity.ServiceAttributesEntity;
import com.ioe.model.MasterData;
import com.ioe.model.Response;
import com.ioe.model.ServiceAttribute;
import com.ioe.repository.MasterDataRepository;
import com.ioe.repository.ServiceAttributeRepository;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Messages;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
@Slf4j
public class MasterDataService {
    @Autowired
    private ServiceAttributeRepository serviceAttributeRepository;
    @Autowired
    private MasterDataRepository masterDataRepository;

    public Response getServiceAttributes(String serviceType) {
        ModelMapper modelMapper = new ModelMapper();
        List<ServiceAttributesEntity> attributesEntities = serviceAttributeRepository.findAllByServiceType(serviceType);
        List<ServiceAttribute> attributes = modelMapper.map(attributesEntities, new TypeToken<List<ServiceAttribute>>() {
        }.getType());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, attributes);
    }

    public Response getMassterData() {
        ModelMapper modelMapper = new ModelMapper();
        List<MasterDataEntity> masterDataEntities = masterDataRepository.findAll();
        List<MasterData> masterData = new ArrayList<>();
        if (masterDataEntities != null)
            masterData = modelMapper.map(masterDataEntities, new TypeToken<List<MasterData>>() {
            }.getType());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, masterData);
    }

    public Response getMassterData(String masterDataType) {
        ModelMapper modelMapper = new ModelMapper();
        List<MasterDataEntity> masterDataEntities = masterDataRepository.findAllByMasterDataTypeOrderByMasterDataOrderNo(masterDataType);
        List<MasterData> masterData = new ArrayList<>();
        if (masterDataEntities != null)
            masterData = modelMapper.map(masterDataEntities, new TypeToken<List<MasterData>>() {
            }.getType());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, masterData);
    }

    public Response getMassterData(String masterDataType, String masterDataCode) {
        ModelMapper modelMapper = new ModelMapper();
        MasterDataEntity masterDataEntity = masterDataRepository.findByMasterDataTypeAndMasterDataCode(masterDataType, masterDataCode);
        MasterData masterData = new MasterData();
        if (masterDataEntity != null)
            masterData = modelMapper.map(masterDataEntity, MasterData.class);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, masterData);
    }

}
