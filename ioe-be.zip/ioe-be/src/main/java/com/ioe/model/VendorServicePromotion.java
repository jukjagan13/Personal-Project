package com.ioe.model;

import lombok.Data;

@Data
public class VendorServicePromotion {
    private String promotionId;
    private String vendorId;
    private String serviceId;
    private String planCode;
    private String status;
    private String promotionStartDate;
    private String promotionEndDate;
    private Float planAmount;
}
