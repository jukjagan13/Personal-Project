package com.ioe.utils;

public class Messages {
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";

    public static final String UNAUTHORIZED_ACTIVITY = "UNAUTHORIZED ACTION";
    public static final String EMAIL_NOT_EXIST = "EMAIL NOT EXIST";
    public static final String EMAIL_EXIST = "EMAIL ALREADY EXIST";
    public static final String WRONG_PASSWORD = "WRONG PASSWORD";
    public static final String EMAIL_NOT_VERIFIED = "EMAIL NOT VERIFIED";
    public static final String ACCOUNT_DEACTIVATED = "ACCOUNT DEACTIVATED";
    public static final String WRONG_OTP = "WRONG OTP";
    public static final String EXPIRED_OTP = "OTP EXPIRED";

    public static final String VENDOR_NOT_FOUND = "VENDOR NOT FOUND";
    public static final String VENDOR_DEACTIVATED = "VENDOR DEACTIVATED";
    public static final String VENDOR_NOT_APPROVED = "VENDOR NOT APPROVED";

    public static final String SERVICE_NOT_FOUND = "SERVICE NOT FOUND";
    public static final String SERVICE_DELETED = "SERVICE DELETED";
    public static final String SERVICE_NOT_PUBLISHED = "SERVICE NOT PUBLISHED";

    public static final String PROMOTION_EXPIRED = "PROMOTION EXPIRED";
    public static final String PROMOTION_NOT_ACTIVE = "PROMOTION PROCESS NOT COMPLETED";
    public static final String ORDER_CREATION_FAILED = "FAILED TO CREATE ORDER";

    public static final String ASSET_NOT_FOUND = "ASSET NOT FOUND";
    public static final String ASSET_DELETED = "ASSET DELETED";

}
