package com.ioe.model;

import lombok.Data;

@Data
public class ServiceAttribute {
    private String serviceType;
    private String attributeDataType;
    private String attributeDesc;
    private String attributeUnit;
    private String attributeValue;
    private Integer attributeOrder;
    private Integer isOptional;
    private Integer isHighlighted;
}
