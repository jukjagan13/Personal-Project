package com.ioe.repository;

import com.ioe.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, String> {

    UserEntity findByUserId(String id);

    List<UserEntity> findByUserType(String userType);

    UserEntity findByVendorId(String id);

    UserEntity findByEmailAddress(String email);

    UserEntity findByEmailAddressAndUserType(String email, String userType);

}
