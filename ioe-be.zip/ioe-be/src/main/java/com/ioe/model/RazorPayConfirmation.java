package com.ioe.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RazorPayConfirmation {
    private String paymentId;
    private String orderId;
    private String signature;
}
