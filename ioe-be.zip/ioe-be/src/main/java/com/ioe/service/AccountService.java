package com.ioe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ioe.entity.AssetEntity;
import com.ioe.entity.UserEntity;
import com.ioe.entity.VendorEntity;
import com.ioe.entity.VerificationCodesEntity;
import com.ioe.model.*;
import com.ioe.repository.CodeGenerator;
import com.ioe.repository.UserRepository;
import com.ioe.repository.VendorRepository;
import com.ioe.repository.VerificationCodesRepository;
import com.ioe.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Base64;
import java.util.HashMap;

@Service
@Slf4j
public class AccountService {
    @Autowired
    private JWTProvider jwtProvider;
    @Autowired
    private CryptoUtil cryptoUtil;
    @Autowired
    private CodeGenerator codeGenerator;
    @Autowired
    private User loggedInUser;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VerificationCodesRepository verificationCodesRepository;
    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private NotificationService notificationService;
    @Autowired
    private VerificationCodeService verificationCodeService;
    @Autowired
    private VendorsService vendorsService;
    @Autowired
    private AssetService assetService;

    public Response signUp(SignUpRequest signUpRequestPayload) {
        log.info("---- Account Service signUp method for {} ----", signUpRequestPayload);
        UserEntity newUser = new UserEntity();
        String timeStamp = new Timestamp(System.currentTimeMillis()).toString();
        UserEntity existUser = userRepository.findByEmailAddress(signUpRequestPayload.getEmail());
        if (existUser == null) {
            String userId = codeGenerator.generateCode(Constants.CODE_USER, null);
            String userSecretEncoded = Base64.getEncoder().encodeToString(signUpRequestPayload.getKey().getBytes());
            String userSecretHashed = cryptoUtil.hashStringSHA26(userSecretEncoded);
            newUser.setUserId(userId);
            newUser.setUserKey(userSecretHashed);
            newUser.setUserType(Constants.USER_TYPE_USER);
            newUser.setUsername(signUpRequestPayload.getUsername());
            newUser.setEmailAddress(signUpRequestPayload.getEmail().toUpperCase());
            newUser.setMobileNumber(signUpRequestPayload.getMobile());
            newUser.setRegisteredTs(timeStamp);
            userRepository.save(newUser);
            log.info("---- Account Service registerUser method user registered userId {} ----", userId);

            VerificationCodesEntity newVerification = verificationCodeService.generate(Constants.VERIFICATION_ACTIVITY_SIGNUP, userId);
            notificationService.signUpVerificationMail(signUpRequestPayload.getEmail(), signUpRequestPayload.getUsername(), newVerification.getCode());
            VerificationCode verificationResponse = new VerificationCode();
            verificationResponse.setDestination(ComUtil.maskEmail(signUpRequestPayload.getEmail()));
            verificationResponse.setMedium(Constants.MEDIUM_EMAIL);
            verificationResponse.setSession(newVerification.getSession());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, verificationResponse);
        } else {
            return ComUtil.response(Codes.USER_EXIST, Messages.EMAIL_EXIST, null);
        }
    }

    public Response registerVendor(SignUpRequest signUpRequestPayload) {
        log.info("---- Account Service signUp method for {} ----", signUpRequestPayload);
        ModelMapper modelMapper = new ModelMapper();
        UserEntity newUser = new UserEntity();
        String timeStamp = new Timestamp(System.currentTimeMillis()).toString();
        UserEntity existUser = userRepository.findByEmailAddressAndUserType(signUpRequestPayload.getEmail().toUpperCase(), Constants.USER_TYPE_VENDOR);
        if (existUser == null) {
            Vendor vendor = new Vendor();
            vendor.setBusinessName(signUpRequestPayload.getUsername());
            vendor.setBusinessEmailAddress(signUpRequestPayload.getEmail());
            vendor.setBusinessMobileNumber(signUpRequestPayload.getMobile());
            vendor.setLocation(signUpRequestPayload.getLocation());
            Response newVendorResponse = vendorsService.createVendor(vendor);
            Vendor newVendor = (Vendor) newVendorResponse.getData();

            UserEntity existingUser = userRepository.findByEmailAddress(signUpRequestPayload.getEmail().toUpperCase());
            String userId = null;
            String userSecretEncoded = Base64.getEncoder().encodeToString(signUpRequestPayload.getKey().getBytes());
            String userSecretHashed = cryptoUtil.hashStringSHA26(userSecretEncoded);
            if(existingUser != null) {
                existingUser.setUserKey(userSecretHashed);
                existingUser.setUserType(Constants.USER_TYPE_VENDOR);
                existingUser.setVendorId(newVendor.getVendorId());
                existingUser.setUsername(signUpRequestPayload.getUsername());
                existingUser.setEmailAddress(signUpRequestPayload.getEmail().toUpperCase());
                existingUser.setMobileNumber(signUpRequestPayload.getMobile());
                userRepository.save(existingUser);
                User registeredUser = modelMapper.map(existingUser, User.class);

                VendorEntity vendorEntity = vendorRepository.findByVendorId(newVendor.getVendorId());
                vendorEntity.setVendorStatus(Constants.VENDOR_STATUS_PENDING);
                vendorRepository.save(vendorEntity);
                notificationService.newVendorRequestMail(vendorEntity);

                return ComUtil.response(Codes.OK, Messages.SUCCESS, registeredUser);
            } else {
                userId = codeGenerator.generateCode(Constants.CODE_USER, null);
                newUser.setUserId(userId);
                newUser.setUserKey(userSecretHashed);
                newUser.setUserType(Constants.USER_TYPE_VENDOR);
                newUser.setVendorId(newVendor.getVendorId());
                newUser.setUsername(signUpRequestPayload.getUsername());
                newUser.setEmailAddress(signUpRequestPayload.getEmail().toUpperCase());
                newUser.setMobileNumber(signUpRequestPayload.getMobile());
                newUser.setRegisteredTs(timeStamp);
                userRepository.save(newUser);
                log.info("---- Account Service registerUser method user registered userId {} ----", userId);

                VerificationCodesEntity newVerification = verificationCodeService.generate(Constants.VERIFICATION_ACTIVITY_SIGNUP, userId);
                notificationService.signUpVerificationMail(signUpRequestPayload.getEmail(), signUpRequestPayload.getUsername(), newVerification.getCode());
                VerificationCode verificationResponse = new VerificationCode();
                verificationResponse.setDestination(ComUtil.maskEmail(signUpRequestPayload.getEmail()));
                verificationResponse.setMedium(Constants.MEDIUM_EMAIL);
                verificationResponse.setSession(newVerification.getSession());
                return ComUtil.response(Codes.OK, Messages.SUCCESS, verificationResponse);
            }
        } else {
            return ComUtil.response(Codes.USER_EXIST, Messages.EMAIL_EXIST, null);
        }
    }

    public Response vendorRegistrationVerification(VerifyEmail verifyEmail) {
        JsonNode sessionData = verificationCodeService.getSessionData(verifyEmail.getSession());
        if (sessionData != null) {
            VerificationCodesEntity codesEntity = verificationCodesRepository.findBySession(verifyEmail.getSession());
            if (codesEntity.getActivity().equalsIgnoreCase(Constants.VERIFICATION_ACTIVITY_SIGNUP)) {
                String userId = sessionData.has("id") ? sessionData.get("id").asText() : null;
                UserEntity userEntity = userRepository.findByUserId(userId);
                if (userId != null && verifyEmail.getEmail().equalsIgnoreCase(userEntity.getEmailAddress())) {
                    VerificationResult verificationResult = verificationCodeService.verify(verifyEmail.getSession(), verifyEmail.getCode());
                    if (verificationResult.isMatched()) {
                        ModelMapper modelMapper = new ModelMapper();
                        userEntity.setEmailVerified(1);
                        userEntity.setIsActive(1);
                        userRepository.save(userEntity);
                        VendorEntity vendorEntity = vendorRepository.findByVendorId(userEntity.getVendorId());
                        vendorEntity.setVendorStatus(Constants.VENDOR_STATUS_PENDING);
                        User user = modelMapper.map(userEntity, User.class);
                        notificationService.newVendorRequestMail(vendorEntity);
                        return ComUtil.response(Codes.OK, Messages.SUCCESS, user);
                    } else if (verificationResult.isMisMatched()) {
                        return ComUtil.response(Codes.WRONG_OTP, Messages.WRONG_OTP, verificationResult.getNoOfTries());
                    } else if (verificationResult.isExpired()) {
                        return ComUtil.response(Codes.EXPIRED, Messages.EXPIRED_OTP, verificationResult.getNoOfTries());
                    }
                }
            }
        }
        return ComUtil.response(Codes.UNAUTHORIZED, Messages.UNAUTHORIZED_ACTIVITY, null);
    }

    public Response resendVerificationEmail(SignInRequest signInRequest) {
        UserEntity existingUser = userRepository.findByEmailAddress(signInRequest.getId());
        if (existingUser != null) {
            VerificationCodesEntity newVerification = verificationCodeService.generate(Constants.VERIFICATION_ACTIVITY_SIGNUP, existingUser.getUserId());
            notificationService.signUpVerificationMail(signInRequest.getId(), existingUser.getUsername(), newVerification.getCode());
            VerificationCode verificationResponse = new VerificationCode();
            verificationResponse.setDestination(ComUtil.maskEmail(signInRequest.getId()));
            verificationResponse.setMedium(Constants.MEDIUM_EMAIL);
            verificationResponse.setSession(newVerification.getSession());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, verificationResponse);
        } else {
            return ComUtil.response(Codes.USER_NOT_FOUND, Messages.EMAIL_NOT_EXIST, null);
        }
    }

    public Response signIn(SignInRequest signInRequest) {
        String timeStamp = new Timestamp(System.currentTimeMillis()).toString();
        UserEntity existingUser = userRepository.findByEmailAddress(signInRequest.getId());
        if (existingUser != null) {
            if (existingUser.getEmailVerified() == 1) {
                if (existingUser.getIsActive() == 1) {
                    SignInResponse signInResponse = new SignInResponse();
                    String userKeyEncoded = Base64.getEncoder().encodeToString(signInRequest.getKey().getBytes());
                    String userKeyHashed = cryptoUtil.hashStringSHA26(userKeyEncoded);
                    if (userKeyHashed.equals(existingUser.getUserKey())) {
                        existingUser.setLastLoggedInTs(timeStamp);
                        userRepository.save(existingUser);
                        String accessToken = jwtProvider.generateAccessToken(signInRequest.getId(), new HashMap<>());
                        signInResponse.setAccessToken(accessToken);
                        return ComUtil.response(Codes.OK, Messages.SUCCESS, signInResponse);
                    } else {
                        return ComUtil.response(Codes.PASSWORD_MISMATCH, Messages.WRONG_PASSWORD, null);
                    }
                } else {
                    return ComUtil.response(Codes.USER_DEACTIVATED, Messages.ACCOUNT_DEACTIVATED, null);
                }
            } else {
                return ComUtil.response(Codes.USER_NOT_VERIFIED, Messages.EMAIL_NOT_VERIFIED, null);
            }
        } else {
            return ComUtil.response(Codes.USER_NOT_FOUND, Messages.EMAIL_NOT_EXIST, null);
        }
    }

    public Response signUpVerification(VerifyEmail verifyEmail) {
        JsonNode sessionData = verificationCodeService.getSessionData(verifyEmail.getSession());
        if (sessionData != null) {
            VerificationCodesEntity codesEntity = verificationCodesRepository.findBySession(verifyEmail.getSession());
            if (codesEntity.getActivity().equalsIgnoreCase(Constants.VERIFICATION_ACTIVITY_SIGNUP)) {
                String userId = sessionData.has("id") ? sessionData.get("id").asText() : null;
                UserEntity userEntity = userRepository.findByUserId(userId);
                if (userId != null && verifyEmail.getEmail().equalsIgnoreCase(userEntity.getEmailAddress())) {
                    VerificationResult verificationResult = verificationCodeService.verify(verifyEmail.getSession(), verifyEmail.getCode());
                    if (verificationResult.isMatched()) {
                        ModelMapper modelMapper = new ModelMapper();
                        userEntity.setEmailVerified(1);
                        userEntity.setIsActive(1);
                        userRepository.save(userEntity);
                        User user = modelMapper.map(userEntity, User.class);
                        return ComUtil.response(Codes.OK, Messages.SUCCESS, user);
                    } else if (verificationResult.isMisMatched()) {
                        return ComUtil.response(Codes.WRONG_OTP, Messages.WRONG_OTP, verificationResult.getNoOfTries());
                    } else if (verificationResult.isExpired()) {
                        return ComUtil.response(Codes.EXPIRED, Messages.EXPIRED_OTP, verificationResult.getNoOfTries());
                    }
                }
            }
        }
        return ComUtil.response(Codes.UNAUTHORIZED, Messages.UNAUTHORIZED_ACTIVITY, null);
    }

    public Response sendForgotPasswordEmail(SignInRequest signInRequest) {
        UserEntity existingUser = userRepository.findByEmailAddress(signInRequest.getId());
        if (existingUser != null) {
            if (existingUser.getIsActive() == 1) {
                VerificationCodesEntity newVerification = verificationCodeService.generate(Constants.VERIFICATION_ACTIVITY_FORGOT, existingUser.getUserId());
                notificationService.forgotPasswordMail(signInRequest.getId(), existingUser.getUsername(), newVerification.getCode());
                VerificationCode verificationResponse = new VerificationCode();
                verificationResponse.setDestination(ComUtil.maskEmail(signInRequest.getId()));
                verificationResponse.setMedium(Constants.MEDIUM_EMAIL);
                verificationResponse.setSession(newVerification.getSession());
                return ComUtil.response(Codes.OK, Messages.SUCCESS, verificationResponse);
            } else {
                return ComUtil.response(Codes.USER_DEACTIVATED, Messages.ACCOUNT_DEACTIVATED, null);
            }
        } else {
            return ComUtil.response(Codes.USER_NOT_FOUND, Messages.EMAIL_NOT_EXIST, null);
        }
    }

    public Response forgotPasswordVerification(VerifyEmail verifyEmail) {
        JsonNode sessionData = verificationCodeService.getSessionData(verifyEmail.getSession());
        if (sessionData != null) {
            VerificationCodesEntity codesEntity = verificationCodesRepository.findBySession(verifyEmail.getSession());
            if (codesEntity.getActivity().equalsIgnoreCase(Constants.VERIFICATION_ACTIVITY_FORGOT)) {
                String userId = sessionData.has("id") ? sessionData.get("id").asText() : null;
                UserEntity userEntity = userRepository.findByUserId(userId);
                if (userId != null && verifyEmail.getEmail().equalsIgnoreCase(userEntity.getEmailAddress())) {
                    VerificationResult verificationResult = verificationCodeService.verify(verifyEmail.getSession(), verifyEmail.getCode());
                    if (verificationResult.isMatched()) {
                        userEntity.setEmailVerified(1);
                        userRepository.save(userEntity);
                        return ComUtil.response(Codes.OK, Messages.SUCCESS, new ObjectMapper().createObjectNode().put("session", verifyEmail.getSession()));
                    } else if (verificationResult.isMisMatched()) {
                        return ComUtil.response(Codes.WRONG_OTP, Messages.WRONG_OTP, verificationResult.getNoOfTries());
                    } else if (verificationResult.isExpired()) {
                        return ComUtil.response(Codes.EXPIRED, Messages.EXPIRED_OTP, verificationResult.getNoOfTries());
                    }
                }
            }
        }
        return ComUtil.response(Codes.UNAUTHORIZED, Messages.UNAUTHORIZED_ACTIVITY, null);
    }

    public Response changePassword(ChangePassword changePassword) {
        ModelMapper modelMapper = new ModelMapper();
        UserEntity userEntity = userRepository.findByEmailAddress(changePassword.getEmail());
        if (userEntity != null) {
            String userSecretEncoded = Base64.getEncoder().encodeToString(changePassword.getNewPassword().getBytes());
            String userSecretHashed = cryptoUtil.hashStringSHA26(userSecretEncoded);
            if (changePassword.getSession() != null) {
                JsonNode sessionData = verificationCodeService.getSessionData(changePassword.getSession());
                if (sessionData != null) {
                    VerificationCodesEntity codesEntity = verificationCodesRepository.findBySession(changePassword.getSession());
                    String userId = sessionData.has("id") ? sessionData.get("id").asText() : null;
                    if (userEntity.getUserId().equals(userId) && codesEntity != null && codesEntity.getActivity().equals(Constants.VERIFICATION_ACTIVITY_FORGOT) && codesEntity.getVerified() == 1) {
                        userEntity.setUserKey(userSecretHashed);
                        userRepository.save(userEntity);
                        User user = modelMapper.map(userEntity, User.class);
                        return ComUtil.response(Codes.OK, Messages.SUCCESS, user);
                    }
                }
            } else if (changePassword.getOldPassword() != null) {
                String userKeyEncoded = Base64.getEncoder().encodeToString(changePassword.getOldPassword().getBytes());
                String userKeyHashed = cryptoUtil.hashStringSHA26(userKeyEncoded);
                if (userKeyHashed.equals(userEntity.getUserKey())) {
                    userEntity.setUserKey(userSecretHashed);
                    userRepository.save(userEntity);
                    User user = modelMapper.map(userEntity, User.class);
                    return ComUtil.response(Codes.OK, Messages.SUCCESS, user);
                } else {
                    return ComUtil.response(Codes.PASSWORD_MISMATCH, Messages.WRONG_PASSWORD, null);
                }
            }
        } else {
            return ComUtil.response(Codes.USER_NOT_FOUND, Messages.EMAIL_NOT_EXIST, null);
        }
        return ComUtil.response(Codes.UNAUTHORIZED, Messages.UNAUTHORIZED_ACTIVITY, null);
    }

    public Response uploadUserLogo(String logoData) {
        ModelMapper modelMapper = new ModelMapper();
        UserEntity userEntity = userRepository.findByUserId(loggedInUser.getUserId());
        Response assetResponse = assetService.uploadAsset(Constants.ASSET_TYPE_USERLOGO, logoData);
        if (assetResponse.getData() != null) {
            AssetEntity asset = (AssetEntity) assetResponse.getData();
            userEntity.setLogoId(asset.getAssetId());
            userRepository.save(userEntity);
            return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(userEntity, User.class));
        }
        return ComUtil.response(Codes.INTERNAL_SERVER_ERROR, Messages.FAILED, null);
    }
}
