package com.ioe.model;

import lombok.Data;

@Data
public class VerifyEmail {
    private String email;
    private String session;
    private Integer code;
}
