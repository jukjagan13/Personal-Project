package com.ioe.filers;

import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.IOException;
import java.util.UUID;

@Component
@Order(value = Integer.MIN_VALUE)
public class TraceFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        MDC.put("api-start-time", "" + System.currentTimeMillis());
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String correlationId = httpServletRequest.getHeader("correlationId");
        if (correlationId == null) {
            correlationId = UUID.randomUUID().toString();
        }
        MDC.put("correlationId", correlationId);

//        HttpServletResponseWrapper responseWrapper = new HttpServletResponseWrapper ((HttpServletResponse) servletResponse);
//        String responseContent = String.valueOf(responseWrapper.getOutputStream());

        filterChain.doFilter(servletRequest, servletResponse);
    }
}
