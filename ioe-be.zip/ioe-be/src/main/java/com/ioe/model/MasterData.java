package com.ioe.model;

import lombok.Data;

@Data
public class MasterData {
    private String masterDataType;
    private String masterDataCode;
    private String masterDataDesc;
    private Integer masterDataOrderNo;
}
