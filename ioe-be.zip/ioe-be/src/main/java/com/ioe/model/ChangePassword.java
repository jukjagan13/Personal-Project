package com.ioe.model;

import lombok.Data;

@Data
public class ChangePassword {
    private String email;
    private String session;
    private String oldPassword;
    private String newPassword;
}
