package com.ioe.entity;

import com.fasterxml.jackson.databind.JsonNode;
import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Data;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "ioe_vendor_services")
@Data
@TypeDef(
        typeClass = JsonStringType.class,
        defaultForType = JsonNode.class
)
public class VendorServiceEntity {
    @Id
    private String serviceId;
    private String vendorId;
    private String serviceType;
    private String serviceName;
    @Column(name = "service_address", columnDefinition = "json")
    private JsonNode address;
    private String branchLocation;
    private String mobileNumber;
    private String serviceLogoId;
    private JsonNode attributes;
    @Column(columnDefinition = "json")
    private JsonNode socialMediaLinks;
    private String aboutUs;
    private Integer isPublished=0;
    private Integer isPromoted=0;
    private Integer isDeleted=0;
    private Timestamp promotionDue;
}
