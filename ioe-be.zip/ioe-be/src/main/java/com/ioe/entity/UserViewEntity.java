package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_user_viewed")
@Data
public class UserViewEntity {
    @Id
    private Integer iuvId;
    private String userId;
    private String serviceType;
    private String serviceId;
    private String sessionId;
    private String viewedTs;
}
