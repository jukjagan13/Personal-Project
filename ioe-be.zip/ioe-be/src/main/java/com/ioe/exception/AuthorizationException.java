package com.ioe.exception;

import lombok.Data;

@Data
public class AuthorizationException extends RuntimeException {

    private String code;
    private String action;
    private String target;

    public AuthorizationException(String target, String action) {
        this.action = action;
        this.target = target;
    }

    @Override
    public String getMessage() {
        return "Target: " + target + "Action: " + action;
    }
}
