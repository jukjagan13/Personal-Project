package com.ioe.repository;

import com.ioe.entity.VendorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorRepository extends JpaRepository<VendorEntity, String> {

    VendorEntity findByVendorId(String vendorId);

}
