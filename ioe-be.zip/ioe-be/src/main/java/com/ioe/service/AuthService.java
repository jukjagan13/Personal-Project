package com.ioe.service;

import com.ioe.entity.UserEntity;
import com.ioe.model.User;
import com.ioe.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(prefix = "app", name = "default-auth", havingValue = "true", matchIfMissing = true)
@Slf4j
public class AuthService {
    @Autowired
    private UserRepository userRepository;

    @Cacheable(cacheNames = "user", key = "#userEmail", unless = "#result == null")
    public User getUserInfo(String userEmail) {
        UserEntity userEntity = null;
        User user = null;
        ModelMapper modelMapper = new ModelMapper();
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null) {
//                userEntity = userRepository.findByUserId(userId);
                userEntity = userRepository.findByEmailAddress(userEmail);
                user = modelMapper.map(userEntity, User.class);
            }
        } catch (Exception re) {
            log.error("User not found", re);
        }
        return user;
    }
}
