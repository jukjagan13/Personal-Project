package com.ioe.utils;

import com.ioe.exception.JwtException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.function.Function;

@Service
@Slf4j
public class JWTProvider {
    @Value("${app.exp:}")
    private long exp;
    @Value("${app.jwt-private-key:}")
    private String jwtPrivateKey;
    @Value("${app.jwt-public-key:}")
    private String jwtPublicKey;

//    public String generateAccessToken(String data) {
//        log.info("---- JWT Provider generateToken method for {} ----", data);
//        Map<String, Object> claims = new HashMap<>();
//        List<String> roles = new ArrayList<>();
//        roles.add("EDITOR");
//        roles.add("PUBLISHER");
//        claims.put("role", roles);
//        String accessToken = Jwts.builder().setClaims(claims).setSubject(data).setIssuedAt(new Date(System.currentTimeMillis()))
//                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000)).signWith(SignatureAlgorithm.HS512, JWT_SECRET).compact();
////                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000)).signWith(SignatureAlgorithm.RS256, JWT_SECRET).compact();
//        log.info("---- JWT Provider generateToken result {} ----", accessToken);
//        return accessToken;
//    }

    public String generateAccessToken(String data, Map<String, Object> claims) {
        log.info("---- JWT Provider generateToken method for {} ----", data);
        PrivateKey privateKey = getPrivateKey();

        String accessToken = Jwts.builder().setClaims(claims)
                .setSubject(data)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + (exp * 1000)))
                .signWith(SignatureAlgorithm.RS512, privateKey).compact();
        log.info("---- JWT Provider generateToken result {} ----", accessToken);
        return accessToken;
    }

    private Boolean isTokenExpired(String accessToken) {
        final Date expiration = getClaimFromToken(accessToken, Claims::getExpiration);
        boolean expired = expiration.before(new Date());
        return expired;
    }

    public boolean validateToken(String token) {
        PublicKey publicKey = getPublicKey();
        Claims claims;
        try {
            claims = Jwts.parser().setSigningKey(publicKey).parseClaimsJws(token).getBody();
            return !claims.isEmpty() && !isTokenExpired(token);
        } catch (ExpiredJwtException e) {
            throw new JwtException("Access token expired", e);
        } catch (Exception e) {
            throw new JwtException("Unable to validate the access token", e);
        }
    }

    public <T> T getClaimFromToken(String accessToken, Function<Claims, T> claimsResolver) {
        try {
            Claims allClaims = getAllClaimsFromToken(accessToken);
            return claimsResolver.apply(allClaims);
        } catch (ExpiredJwtException e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new JwtException("Access token expired", e);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new JwtException("Unable to validate the access token", e);
        }
    }

    public Claims getAllClaimsFromToken(String accessToken) {
        try {
            PublicKey publicKey = getPublicKey();
            Claims allClaims = Jwts.parser().setSigningKey(publicKey).parseClaimsJws(accessToken).getBody();
            if (allClaims.getSubject().isEmpty()) {
                log.error("No subject available in token");
                throw new JwtException("Unable to validate the access token");
            }
            return allClaims;
        } catch (ExpiredJwtException e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new JwtException("Access token expired", e);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            throw new JwtException("Unable to validate the access token", e);
        }
    }

    public String getUsernameFromToken(String accessToken) {
        if (isTokenExpired(accessToken)) {
            log.error("Access token expired");
            throw new JwtException("Access token expired");
        }

        return getClaimFromToken(accessToken, Claims::getSubject);
    }

    public PublicKey getPublicKey() {
//        Resource publicFile = new ClassPathResource("/public.pub");
//        File publicFile = new File("/public.pub");
        PublicKey pubKey = null;
        try {
//            byte[] keyBytes = Files.readAllBytes(new File(publicFile.getURI()).toPath());
            byte[] keyBytes = jwtPublicKey.getBytes();
            String privateKeyContent = new String(keyBytes);
            privateKeyContent = privateKeyContent.replaceAll("[\\t\\n\\r]", "")
                    .replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "");
            KeyFactory kf = KeyFactory.getInstance("RSA");
            byte[] encoded = Base64.getDecoder().decode(privateKeyContent);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(encoded);
            pubKey = kf.generatePublic(keySpec);
        } catch (Exception e) {
            log.error(e.getMessage());
            e.printStackTrace();
        }
        return pubKey;
    }

    public PrivateKey getPrivateKey() {
//        Resource privateFile = new ClassPathResource("/private.key");
//        File privateFile = new File("/private.key");
        PrivateKey priKey = null;
        try {
//            byte[] keyBytes = Files.readAllBytes(new File(privateFile.getURI()).toPath()); // Absolute Path to be replaced
            byte[] keyBytes = jwtPrivateKey.getBytes();
            String privateKeyContent = new String(keyBytes);
            privateKeyContent = privateKeyContent.replaceAll("[\\t\\n\\r]", "")
                    .replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "");
            KeyFactory kf = KeyFactory.getInstance("RSA");
            byte[] encoded = Base64.getDecoder().decode(privateKeyContent);
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(encoded);
            priKey = kf.generatePrivate(keySpec);
        } catch (Exception e) {
            log.error(e.getMessage());
            e.printStackTrace();
        }
        return priKey;
    }
}
