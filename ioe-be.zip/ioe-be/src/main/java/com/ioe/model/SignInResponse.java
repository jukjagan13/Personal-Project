package com.ioe.model;

import lombok.Data;

@Data
public class SignInResponse {
    private String accessToken;
}
