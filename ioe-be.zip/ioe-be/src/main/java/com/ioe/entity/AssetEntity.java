package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_assets")
@Data
public class AssetEntity {
    @Id
    private String assetId;
    private String assetType;
    private Double assetSize;
    private String assetExtension;
    private String assetData;
}
