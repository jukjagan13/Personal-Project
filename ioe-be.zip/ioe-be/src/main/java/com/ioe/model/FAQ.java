package com.ioe.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class FAQ {
    @JsonProperty("faqQuestion")
    private String question;
    @JsonProperty("faqAnswer")
    private String answer;
}
