package com.ioe.controller;

import com.ioe.model.*;
import com.ioe.service.AccountService;
import com.ioe.service.AssetService;
import com.ioe.service.MessageService;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Messages;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("account")
public class AccountController {
    @Autowired
    private User loggedInUser;

    @Autowired
    private AccountService accountService;
    @Autowired
    private MessageService messageService;
    @Autowired
    private AssetService assetService;

    @Value("${app.public-login.email:}")
    private String publicEmail;
    @Value("${app.public-login.password:}")
    private String publicEmailPassword;

    @PostMapping("signup")
    public Response signUpUser(@Valid @RequestBody SignUpRequest payload) {
        return accountService.signUp(payload);
    }

    @PostMapping("signin")
    public Response signInUser(@Valid @RequestBody SignInRequest payload) {
        return accountService.signIn(payload);
    }

    @PostMapping("signup/resend")
    public Response resendVerifyEmail(@RequestBody SignInRequest signInRequest) {
        return accountService.resendVerificationEmail(signInRequest);
    }

    @PostMapping("signup/verify")
    public Response verifySignUpEmail(@RequestBody VerifyEmail verifyEmail) {
        return accountService.signUpVerification(verifyEmail);
    }

    @PostMapping("forgot-password")
    public Response forgotPassword(@RequestBody SignInRequest signInRequest) {
        return accountService.sendForgotPasswordEmail(signInRequest);
    }

    @PostMapping("forgot-password/verify")
    public Response verifyForgotPassword(@RequestBody VerifyEmail verifyEmail) {
        return accountService.forgotPasswordVerification(verifyEmail);
    }

    @PostMapping("forgot-password/resend")
    public Response resendForgotPasswordEmail(@RequestBody SignInRequest signInRequest) {
        return accountService.sendForgotPasswordEmail(signInRequest);
    }

    @PostMapping("change-password")
    public Response changePassword(@RequestBody ChangePassword changePassword) {
        return accountService.changePassword(changePassword);
    }

    @PostMapping("vendor/signup")
    public Response registerVendor(@Valid @RequestBody SignUpRequest payload) {
        return accountService.registerVendor(payload);
    }

    @PostMapping("vendor/verify")
    public Response verifyVendor(@Valid @RequestBody VerifyEmail verifyEmail) {
        return accountService.vendorRegistrationVerification(verifyEmail);
    }

    @PostMapping("logo")
    public Response uploadLogo(@RequestBody String file) {
        return accountService.uploadUserLogo(file);
    }

    @GetMapping("user")
    public Response getLoggedInUser() {
        User user = new User();
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.map(loggedInUser, user);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, user);
    }

    @GetMapping("public")
    public Response getPublicToken() {
        SignInRequest signInRequest = new SignInRequest();
        signInRequest.setId(publicEmail);
        signInRequest.setKey(publicEmailPassword);
        return accountService.signIn(signInRequest);
    }
}
