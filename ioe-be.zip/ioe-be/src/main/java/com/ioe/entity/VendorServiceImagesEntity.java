package com.ioe.entity;

import lombok.Data;
import org.hibernate.boot.model.naming.Identifier;

import javax.persistence.*;

@Entity
@Table(name = "ioe_vendor_service_images")
@Data
public class VendorServiceImagesEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ivsi;
    private String vendorServiceId;
    private String vendorImageId;
    private Integer isDeleted = 0;
    private String uploadedTs;
    private String deletedTs;
}
