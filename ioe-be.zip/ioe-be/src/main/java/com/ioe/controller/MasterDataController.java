package com.ioe.controller;

import com.ioe.model.Response;
import com.ioe.model.ServiceAttribute;
import com.ioe.repository.ServiceAttributeRepository;
import com.ioe.service.MasterDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("master")
@Slf4j
public class MasterDataController {
    @Autowired
    private MasterDataService masterDataService;

    @GetMapping("service/{serviceType}/attributes")
    public Response getServiceAttributes(@PathVariable String serviceType) {
        return masterDataService.getServiceAttributes(serviceType);
    }

    @GetMapping("all")
    public Response getMasterData() {
        return masterDataService.getMassterData();
    }

    @GetMapping("type/{masterDataType}")
    public Response getMasterData(@PathVariable String masterDataType) {
        return masterDataService.getMassterData(masterDataType);
    }

    @GetMapping("type/{masterDataType}/code/{masterDataCode}")
    public Response getMasterData(@PathVariable String masterDataType, @PathVariable String masterDataCode) {
        return masterDataService.getMassterData(masterDataType, masterDataCode);
    }
}
