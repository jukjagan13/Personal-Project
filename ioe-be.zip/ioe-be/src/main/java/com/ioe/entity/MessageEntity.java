package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_messages")
@Data
public class MessageEntity {
    @Id
    private String messageId;
    private String senderType;
    private String senderId;
    private String receiverType;
    private String receiverId;
    private String messageContent;
    private Integer isRead;
    private String messagedTs;
}
