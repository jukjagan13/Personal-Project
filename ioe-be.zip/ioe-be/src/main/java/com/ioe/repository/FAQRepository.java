package com.ioe.repository;

import com.ioe.entity.FAQEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FAQRepository extends JpaRepository<FAQEntity, Integer> {

    List<FAQEntity> findAllByAppSection(String appSection);
}
