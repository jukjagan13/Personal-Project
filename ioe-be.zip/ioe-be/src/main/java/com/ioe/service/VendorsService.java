package com.ioe.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ioe.entity.*;
import com.ioe.model.*;
import com.ioe.repository.*;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Constants;
import com.ioe.utils.Messages;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MatchingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class VendorsService {
    @Autowired
    private VendorRepository vendorRepository;
    @Autowired
    private VendorServiceRepository vendorServiceRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VendorServiceImagesRepository vendorServiceImagesRepository;

    @Autowired
    private CodeGenerator codeGenerator;
    @Autowired
    private User loggedInUser;

    @Autowired
    private AssetService assetService;
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private MasterDataService masterDataService;

    public Response createVendor(Vendor vendor) {
        ModelMapper modelMapper = new ModelMapper();
        String currentTimestamp = new Timestamp(System.currentTimeMillis()).toString();
        VendorEntity newVendor = modelMapper.map(vendor, VendorEntity.class);
        newVendor.setBusinessEmailAddress(vendor.getBusinessEmailAddress().toUpperCase());
        if (vendor.getVendorId() == null) {
            newVendor.setVendorId(codeGenerator.generateCode(Constants.CODE_VENDOR, null));
            newVendor.setCreatedTs(currentTimestamp);
        } else {
            UserEntity existingVendor = userRepository.findByVendorId(vendor.getVendorId());
            if (existingVendor != null && !existingVendor.getEmailAddress().equalsIgnoreCase(vendor.getBusinessEmailAddress())) {
                existingVendor.setEmailVerified(0);
                userRepository.save(existingVendor);
            }
        }
        if (loggedInUser.getUserType() != null && loggedInUser.getUserType().equals(Constants.USER_TYPE_ADMIN)) {
            newVendor.setVendorStatus(Constants.VENDOR_STATUS_APPROVED);
        } else if (newVendor.getVendorStatus() == null) {
            newVendor.setVendorStatus(Constants.VENDOR_STATUS_CREATED);
        }
        vendorRepository.save(newVendor);
        List<VendorService> newServices = new ArrayList<>();
        if (vendor.getServices() != null && vendor.getServices().size() > 0) {
            vendor.getServices().forEach(service -> {
                service.setVendorId(newVendor.getVendorId());
                VendorService newService = (VendorService) addVendorService(newVendor.getVendorId(), service).getData();
                newServices.add(newService);
            });
        }
        vendor = modelMapper.map(newVendor, Vendor.class);
        vendor.setServices(newServices);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, vendor);
    }

    public Response addVendorService(String vendorId, VendorService vendorService) {
        ModelMapper modelMapper = new ModelMapper();
        // VendorServiceEntity newVendorService = modelMapper.map(vendorService, VendorServiceEntity.class);
        VendorServiceEntity newVendorService = new VendorServiceEntity();
        newVendorService.setVendorId(vendorService.getVendorId());
        newVendorService.setServiceId(vendorService.getServiceId());
        newVendorService.setServiceType(vendorService.getServiceType());
        newVendorService.setServiceName(vendorService.getServiceName());
        newVendorService.setBranchLocation(vendorService.getBranchLocation());
        newVendorService.setAddress(vendorService.getAddress());
        newVendorService.setMobileNumber(vendorService.getMobileNumber());
        newVendorService.setServiceLogoId(vendorService.getServiceLogoId());
        newVendorService.setAttributes(vendorService.getAttributes());
        newVendorService.setSocialMediaLinks(vendorService.getSocialMediaLinks());
        newVendorService.setAboutUs(vendorService.getAboutUs());
        newVendorService.setIsPublished(vendorService.getIsPublished());
        // newVendorService.setIsPromoted(vendorService.getIsPromoted());
        // newVendorService.setPromotionDue(vendorService.getPromotionDue());
        if (vendorService.getServiceId() == null) {
            newVendorService.setServiceId(codeGenerator.generateCode(Constants.CODE_VENDOR_SERVICE, null));
            newVendorService.setIsPromoted(0);
            newVendorService.setPromotionDue(null);
            newVendorService.setIsPublished(0);
            newVendorService.setVendorId(vendorId);
        } else {
            VendorServiceEntity existingService = vendorServiceRepository.findByServiceId(vendorService.getServiceId());
            newVendorService.setIsPublished(existingService.getIsPublished());
            newVendorService.setIsPromoted(existingService.getIsPromoted());
            newVendorService.setPromotionDue(existingService.getPromotionDue());
            newVendorService.setIsDeleted(existingService.getIsDeleted());
            newVendorService.setServiceLogoId(existingService.getServiceLogoId());
        }
        vendorServiceRepository.save(newVendorService);
        vendorService = modelMapper.map(newVendorService, VendorService.class);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorService);
    }

    public Response activateVendor(String vendorId) {
        VendorEntity vendor = vendorRepository.findByVendorId(vendorId);
        if (vendor != null) {
            ModelMapper modelMapper = new ModelMapper();
            vendor.setIsActive(1);
            vendorRepository.save(vendor);
            UserEntity user = userRepository.findByVendorId(vendorId);
            if (user != null) {
                user.setIsActive(1);
                userRepository.save(user);
                notificationService.accountActivated(user.getEmailAddress(), user.getUsername());
            }
            return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(vendor, Vendor.class));
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response deActivateVendor(String vendorId) {
        VendorEntity vendor = vendorRepository.findByVendorId(vendorId);
        if (vendor != null) {
            ModelMapper modelMapper = new ModelMapper();
            vendor.setIsActive(0);
            vendorRepository.save(vendor);
            UserEntity user = userRepository.findByVendorId(vendorId);
            if (user != null) {
                user.setIsActive(0);
                userRepository.save(user);
                notificationService.accountDeactivated(user.getEmailAddress(), user.getUsername());
            }
            return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(vendor, Vendor.class));
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response approveVendor(String vendorId) {
        VendorEntity vendor = vendorRepository.findByVendorId(vendorId);
        if (vendor != null) {
            ModelMapper modelMapper = new ModelMapper();
            vendor.setVendorStatus(Constants.VENDOR_STATUS_APPROVED);
            vendor.setIsActive(1);
            vendorRepository.save(vendor);
            notificationService.vendorApproved(vendor.getBusinessEmailAddress(), vendor.getBusinessName());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(vendor, Vendor.class));
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response rejectVendor(String vendorId) {
        VendorEntity vendor = vendorRepository.findByVendorId(vendorId);
        if (vendor != null) {
            ModelMapper modelMapper = new ModelMapper();
            vendor.setVendorStatus(Constants.VENDOR_STATUS_REJECTED);
            vendorRepository.save(vendor);
            vendor.setIsActive(0);
            notificationService.vendorRejected(vendor.getBusinessEmailAddress(), vendor.getBusinessName());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(vendor, Vendor.class));
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response deleteVendorService(String serviceId) {
        VendorServiceEntity service = vendorServiceRepository.findByServiceId(serviceId);
        if (service != null) {
            service.setIsDeleted(1);
            vendorServiceRepository.save(service);
            return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
        } else {
            return ComUtil.response(Codes.SERVICE_NOT_FOUND, Messages.SERVICE_NOT_FOUND, null);
        }
    }

    public Response publishVendorService(String serviceId) {
        ModelMapper modelMapper = new ModelMapper();
        VendorServiceEntity service = vendorServiceRepository.findByServiceId(serviceId);
        if (service != null) {
            if (service.getIsDeleted() != 1) {
                service.setIsPublished(1);
                vendorServiceRepository.save(service);
                return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(service, VendorsService.class));
            } else {
                return ComUtil.response(Codes.SERVICE_DELETED, Messages.SERVICE_DELETED, null);
            }
        } else {
            return ComUtil.response(Codes.SERVICE_NOT_FOUND, Messages.SERVICE_NOT_FOUND, null);
        }
    }

    public Response unPublishVendorService(String serviceId) {
        ModelMapper modelMapper = new ModelMapper();
        VendorServiceEntity service = vendorServiceRepository.findByServiceId(serviceId);
        if (service != null) {
            if (service.getIsDeleted() != 1) {
                service.setIsPublished(0);
                vendorServiceRepository.save(service);
                return ComUtil.response(Codes.OK, Messages.SUCCESS, modelMapper.map(service, VendorsService.class));
            } else {
                return ComUtil.response(Codes.SERVICE_DELETED, Messages.SERVICE_DELETED, null);
            }
        } else {
            return ComUtil.response(Codes.SERVICE_NOT_FOUND, Messages.SERVICE_NOT_FOUND, null);
        }
    }

    public Response addServiceImages(String vendorId, String serviceId, List<String> images) {
        List<VendorServiceImage> vendorServiceImages = new ArrayList<>();
        String timestamp = new Timestamp(System.currentTimeMillis()).toString();
        if (images != null && images.size() > 0) {
            //Delete Existing Images
            List<VendorServiceImagesEntity> existingImages = vendorServiceImagesRepository.findAllByVendorServiceIdAndIsDeleted(serviceId, 0);
            // existingImages = existingImages.stream().map(s -> s.setIsDeleted(1)).collect(Collectors.toList());
            for(VendorServiceImagesEntity image: existingImages) {
                image.setIsDeleted(1);
            }
            vendorServiceImagesRepository.saveAll(existingImages);

            images.forEach(image -> {
                Response newImageResponse = assetService.uploadAsset(Constants.ASSET_TYPE_VENDORSERVICE, image);
                if (newImageResponse.getCode().equals(Codes.OK)) {
                    AssetEntity newImage = (AssetEntity) newImageResponse.getData();
                    VendorServiceImagesEntity newVendorServiceImagesEntity = new VendorServiceImagesEntity();
                    newVendorServiceImagesEntity.setVendorServiceId(serviceId);
                    newVendorServiceImagesEntity.setVendorImageId(newImage.getAssetId());
                    newVendorServiceImagesEntity.setUploadedTs(timestamp);
                    vendorServiceImagesRepository.save(newVendorServiceImagesEntity);

                    VendorServiceImage vendorServiceImage = new VendorServiceImage();
                    vendorServiceImage.setVendorImageId(newImage.getAssetId());
                    vendorServiceImage.setUploadedTs(timestamp);
                    vendorServiceImage.setImageData((Asset) assetService.getAsset(newImage.getAssetId()).getData());
                    vendorServiceImages.add(vendorServiceImage);
                }
            });
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorServiceImages);
    }

    public Response setServiceLogo(String vendorId, String serviceId, String logo) {
        if (logo != null) {
            Response newImageResponse = assetService.uploadAsset(Constants.ASSET_TYPE_VENDORLOGO, logo);
            if (newImageResponse.getCode().equals(Codes.OK)) {
                AssetEntity newImage = (AssetEntity) newImageResponse.getData();
                VendorServiceEntity vendorServiceEntity = vendorServiceRepository.findByServiceId(serviceId);
                if (vendorServiceEntity != null) {
                    vendorServiceEntity.setServiceLogoId(newImage.getAssetId());
                    vendorServiceRepository.save(vendorServiceEntity);
                    VendorService vendorService = new ModelMapper().map(vendorServiceEntity, VendorService.class);
                    return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorService);
                } else {
                    return ComUtil.response(Codes.SERVICE_NOT_FOUND, Messages.SERVICE_NOT_FOUND, null);
                }
            }
        }
        return ComUtil.response(Codes.INTERNAL_SERVER_ERROR, Messages.FAILED, null);
    }

    public Response deleteServiceImage(String vendorId, String serviceId, String imageId) {
        VendorServiceImagesEntity vendorServiceImageEntity = vendorServiceImagesRepository.findAllByVendorServiceIdAndVendorImageId(serviceId, imageId);
        if (vendorServiceImageEntity != null) {
            vendorServiceImageEntity.setIsDeleted(1);
            vendorServiceImageEntity.setDeletedTs(new Timestamp(System.currentTimeMillis()).toString());
            vendorServiceImagesRepository.save(vendorServiceImageEntity);
        }
        return ComUtil.response(Codes.ASSET_NOT_FOUNT, Messages.ASSET_NOT_FOUND, null);
    }

    public Response getServiceImages(String vendorId, String serviceId, Integer limit) {
        List<VendorServiceImagesEntity> vendorServiceImagesEntities = vendorServiceImagesRepository.findAllByVendorServiceIdAndIsDeleted(serviceId, 0);
        Collections.sort(vendorServiceImagesEntities, Comparator.comparing(VendorServiceImagesEntity::getUploadedTs).reversed());
        List<VendorServiceImage> vendorImages = vendorServiceImagesEntities.stream().map(i -> {
            VendorServiceImage serviceImage = new VendorServiceImage();
            serviceImage.setVendorImageId(i.getVendorImageId());
            serviceImage.setImageData((Asset) assetService.getAsset(i.getVendorImageId()).getData());
            serviceImage.setUploadedTs(i.getUploadedTs());
            return serviceImage;
        }).collect(Collectors.toList());

        if (limit != null) {
            vendorImages = vendorImages.stream().limit(limit).collect(Collectors.toList());
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorImages);
    }

    public Response getServiceImages(String vendorId, String serviceId, String imageId) {
        VendorServiceImagesEntity vendorServiceImagesEntity = vendorServiceImagesRepository.findAllByVendorServiceIdAndVendorImageIdAndIsDeleted(serviceId, imageId, 0);
        if (vendorServiceImagesEntity != null) {
            if (vendorServiceImagesEntity.getIsDeleted() == 1) {
                VendorServiceImage serviceImage = new VendorServiceImage();
                serviceImage.setVendorImageId(vendorServiceImagesEntity.getVendorImageId());
                serviceImage.setImageData((Asset) assetService.getAsset(vendorServiceImagesEntity.getVendorImageId()).getData());
                serviceImage.setUploadedTs(vendorServiceImagesEntity.getUploadedTs());
                return ComUtil.response(Codes.OK, Messages.SUCCESS, serviceImage);
            } else {
                return ComUtil.response(Codes.ASSET_DELETED, Messages.ASSET_DELETED, null);
            }
        } else {
            return ComUtil.response(Codes.ASSET_NOT_FOUNT, Messages.ASSET_NOT_FOUND, null);
        }
    }

    public Response getVendors(Boolean isActive, Boolean withService) {
        if (isActive == null)
            isActive = false;
        if (withService == null)
            withService = false;
        ModelMapper modelMapper = new ModelMapper();
        List<Vendor> vendors = new ArrayList<>();
        List<VendorEntity> vendorsEntity = vendorRepository.findAll();
        Collections.sort(vendorsEntity, Comparator.comparing(VendorEntity::getBusinessName));
        if (isActive) {
            vendorsEntity = vendorsEntity.stream().filter(v -> v.getIsActive().equals(1)).collect(Collectors.toList());
        }

        if (vendorsEntity != null) {
            vendors = modelMapper.map(vendorsEntity, new TypeToken<List<Vendor>>() {
            }.getType());
            if (withService) {
                for (Vendor vendor : vendors) {
                    List<VendorService> vendorServices = (List<VendorService>) getVendorServices(vendor.getVendorId()).getData();
                    vendor.setServices(vendorServices);
                }
            }
            return ComUtil.response(Codes.OK, Messages.SUCCESS, vendors);
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response getVendor(String vendorId, Boolean ignoreStatus) {
        if (ignoreStatus == null)
            ignoreStatus = false;
        ModelMapper modelMapper = new ModelMapper();
        VendorEntity vendorEntity = vendorRepository.findByVendorId(vendorId);
        if (vendorEntity != null) {
            if (vendorEntity.getIsActive() == 1 || ignoreStatus) {
                if (vendorEntity.getVendorStatus().equals(Constants.VENDOR_STATUS_APPROVED) || ignoreStatus) {
                    Vendor vendor = modelMapper.map(vendorEntity, Vendor.class);
                    List<VendorService> vendorServices = (List<VendorService>) getVendorServices(vendorId).getData();
//                    List<VendorServiceEntity> vendorServiceEntities = vendorServiceRepository.findByVendorId(vendorId);
//                    vendorServiceEntities = vendorServiceEntities.stream().filter(s -> s.getIsDeleted() == 0).collect(Collectors.toList());
//                    Collections.sort(vendorServiceEntities, Comparator.comparing(VendorServiceEntity::getServiceName));
//                    List<VendorService> vendorServices = modelMapper.map(vendorServiceEntities, new TypeToken<List<VendorService>>() {
//                    }.getType());
                    vendor.setServices(vendorServices);
                    return ComUtil.response(Codes.OK, Messages.SUCCESS, vendor);
                } else {
                    return ComUtil.response(Codes.VENDOR_NOT_APPROVED, Messages.VENDOR_NOT_APPROVED, null);
                }
            } else {
                return ComUtil.response(Codes.VENDOR_DEACTIVATED, Messages.VENDOR_DEACTIVATED, null);
            }
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response getVendorServices(String vendorId) {
        ModelMapper modelMapper = new ModelMapper();
        VendorEntity vendorEntity = vendorRepository.findByVendorId(vendorId);
        if (vendorEntity != null) {
            List<VendorServiceEntity> vendorServiceEntities = vendorServiceRepository.findByVendorId(vendorId);
            vendorServiceEntities = vendorServiceEntities.stream().filter(s -> s.getIsDeleted() == 0).collect(Collectors.toList());
            Collections.sort(vendorServiceEntities, Comparator.comparing(VendorServiceEntity::getServiceName));
            vendorServiceEntities.forEach(vs -> {
                if (vs.getIsPromoted() == 1 && vs.getPromotionDue() != null) {
                    Calendar cal = Calendar.getInstance();
//                    Date promotionDue = ComUtil.convertStringToDate(vs.getPromotionDue());
                    Date promotionDue = new Date(vs.getPromotionDue().getTime());
                    if (cal.getTime().after(promotionDue)) {
                        vs.setPromotionDue(null);
                        vs.setIsPromoted(0);
                        vendorServiceRepository.save(vs);
                    }
                }
            });
            List<VendorService> vendorServices = modelMapper.map(vendorServiceEntities, new TypeToken<List<VendorService>>() {
            }.getType());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorServices);
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response getVendorService(String vendorId, String serviceId) {
        ModelMapper modelMapper = new ModelMapper();
        VendorEntity vendorEntity = vendorRepository.findByVendorId(vendorId);
        if (vendorEntity != null) {
            VendorServiceEntity vendorService = vendorServiceRepository.findByServiceId(serviceId);
            if (vendorService.getIsPromoted() == 1 && vendorService.getPromotionDue() != null) {
                Calendar cal = Calendar.getInstance();
                Date promotionDue = new Date(vendorService.getPromotionDue().getTime());
                if (cal.getTime().after(promotionDue)) {
                    vendorService.setPromotionDue(null);
                    vendorService.setIsPromoted(0);
                    vendorServiceRepository.save(vendorService);
                }
            }
            VendorService service = modelMapper.map(vendorService, VendorService.class);
            if(service.getServiceLogoId() != null) {
                service.setServiceLogo((Asset) assetService.getAsset(service.getServiceLogoId()).getData());
            }
            return ComUtil.response(Codes.OK, Messages.SUCCESS, service);
        } else {
            return ComUtil.response(Codes.VENDOR_NOT_FOUND, Messages.VENDOR_NOT_FOUND, null);
        }
    }

    public Response getVendorServices(List<String> serviceIds) {
        ModelMapper modelMapper = new ModelMapper();
        List<VendorServiceEntity> vendorServices = vendorServiceRepository.findAllByServiceIds(serviceIds);
//        List<VendorService> services = modelMapper.map(vendorServices, new TypeToken<List<VendorService>>() {
//        }.getType());
        List<VendorService> services = new ArrayList<>();
        vendorServices.forEach(service -> {
            Response serviceData = getVendorService(service.getVendorId(), service.getServiceId());
            if(serviceData.getCode().equals(Codes.OK)) {
                services.add((VendorService) serviceData.getData());
            }
        });
        return ComUtil.response(Codes.OK, Messages.SUCCESS, services);
    }

    public Response getServices(String keyword, List<String> serviceTypes, String location, Boolean shuffle, Boolean promoted, Integer limit) {
        ModelMapper modelMapper = new ModelMapper();
        List<VendorServiceEntity> serviceEntities = new ArrayList<>();
        if (keyword == null) {
            keyword = "";
        }
        if (location == null) {
            location = "";
        }
        if(limit == null) {
            limit = Integer.MAX_VALUE;
        }
        if(serviceTypes.size() < 1) {
            List<MasterData> serviceTypesMasData = (List<MasterData>) masterDataService.getMassterData(Constants.MAS_DATA_TYPE_SERVICE).getData();
            serviceTypes.addAll(serviceTypesMasData.stream().map(s -> s.getMasterDataCode()).collect(Collectors.toList()));
        }
        for (String serviceType : serviceTypes) {
            List<VendorServiceEntity> services = vendorServiceRepository.findAllByServiceNameAndServiceTypeAndLocation(keyword, serviceType, location.toUpperCase());
            if (shuffle != null && shuffle) {
                Collections.shuffle(services);
            }
            services = services.stream().filter(s -> s.getIsDeleted() == 0 && s.getIsPublished() == 1).limit(limit).collect(Collectors.toList());
            Collections.sort(serviceEntities, Comparator.comparing(VendorServiceEntity::getServiceName));
            serviceEntities.addAll(services);
        }
//        serviceEntities = serviceEntities.stream().filter(s -> s.getIsPublished() == 1).collect(Collectors.toList());
        if (promoted != null && promoted) {
            serviceEntities = serviceEntities.stream().filter(s -> s.getIsPromoted() == 1).collect(Collectors.toList());
        }
        List<VendorService> services = modelMapper.map(serviceEntities, new TypeToken<List<VendorService>>() {
        }.getType());

        services = services.stream().map(service -> {
            service.setServiceLogo((Asset) assetService.getAsset(service.getServiceLogoId()).getData());
            return service;
        }).collect(Collectors.toList());

        return ComUtil.response(Codes.OK, Messages.SUCCESS, services);
    }

    public Response getServicesBasic(String keyword, List<String> serviceType, String location, Boolean shuffle, Boolean promoted, Integer limit) {
        ModelMapper modelMapper = new ModelMapper();
//        modelMapper.getConfiguration().setAmbiguityIgnored(true);
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        Response serviceResponse = getServices(keyword, serviceType, location, shuffle, promoted, limit);
        List<VendorService> services = (List<VendorService>) serviceResponse.getData();
        List<VendorServiceMini> serviceMinis = modelMapper.map(services, new TypeToken<List<VendorServiceMini>>() {
        }.getType());
        serviceMinis = serviceMinis.stream().map(service -> {
            service.setHighlightedAttributes(getHighlightedServiceAttributes(service.getServiceId()));
//            service.setServiceLogo((Asset) assetService.getAsset(service.getServiceLogoId()).getData());
            return service;
        }).collect(Collectors.toList());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, serviceMinis);
    }

    public Response getFeaturedServicesLogo(List<String> serviceType, Integer limit) {
        if(limit == null)
            limit = 10;
        ModelMapper modelMapper = new ModelMapper();
        //Fixme: Filter only promoted here
        Response serviceResponse = getServices(null, serviceType, null, true, false, limit);
        List<VendorService> services = (List<VendorService>) serviceResponse.getData();
        List<String> logoIds = services.stream().map(VendorService::getServiceLogoId).limit(limit).collect(Collectors.toList());
        List<Asset> logos = logoIds.stream().map(l -> (Asset) assetService.getAsset(l).getData()).collect(Collectors.toList());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, logos);
    }

    private List<ServiceAttribute> getHighlightedServiceAttributes(String serviceId) {
        ObjectMapper objectMapper = new ObjectMapper();
        VendorServiceEntity vendorServiceEntity = vendorServiceRepository.findByServiceId(serviceId);
        List<ServiceAttribute> serviceAttributes = new ArrayList<>();
        if (vendorServiceEntity.getAttributes() != null) {
            serviceAttributes = objectMapper.convertValue(vendorServiceEntity.getAttributes(), new TypeReference<List<ServiceAttribute>>() {
            });
            serviceAttributes = serviceAttributes.stream().filter(attr -> attr.getIsHighlighted() != null && attr.getIsHighlighted().equals(1)).collect(Collectors.toList());
        }
        return serviceAttributes;
    }
}
