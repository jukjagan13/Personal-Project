package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_users")
@Data
public class UserEntity {
    @Id
    private String userId;
    private String vendorId;
    private String username;
    private String userType;
    private String mobileNumber;
    private String emailAddress;
    private String userKey;
    private String logoId;
    private Integer isActive = 0;
    private Integer emailVerified = 0;
    private String registeredTs;
    private String lastLoggedInTs;
}
