package com.ioe.service;

import com.ioe.entity.AssetEntity;
import com.ioe.model.Asset;
import com.ioe.model.Response;
import com.ioe.repository.AssetRepository;
import com.ioe.repository.CodeGenerator;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Constants;
import com.ioe.utils.Messages;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class AssetService {

    @Autowired
    private CodeGenerator codeGenerator;
    @Autowired
    private AssetRepository assetRepository;

    public Response uploadAsset(String assetType, String fileData) {
        String content = null;
        String docType = null;
        try {
            String[] parts = StringUtils.split(fileData, ",");
            docType = StringUtils.split(StringUtils.split(parts[0], ";")[0], ":")[1];
//            docExtension = StringUtils.split(docType, "/")[1];
            content = parts[1];
        } catch (Exception e) {
            e.printStackTrace();
        }
        Integer fileSize = null;
        if (content.length() > 0)
            fileSize = ((content.length() * 3) / 4) - (content.substring(content.length() - 2).equals("==") ? 2 : (content.substring(content.length() - 1).equals("=") ? 1 : 0));
        AssetEntity newAsset = new AssetEntity();
        newAsset.setAssetId(codeGenerator.generateCode(Constants.CODE_ASSET, null));
        newAsset.setAssetExtension(docType);
        newAsset.setAssetSize(new Double(fileSize));
        newAsset.setAssetType(assetType);
        newAsset.setAssetData(content);
        assetRepository.save(newAsset);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, newAsset);
    }

    public Response getAsset(String assetId) {
        AssetEntity assetEntity = assetRepository.findByAssetId(assetId);
        if (assetEntity != null) {
            Asset asset = new Asset();
            asset.setId(assetEntity.getAssetId());
            asset.setContentType(assetEntity.getAssetExtension());
            asset.setData(assetEntity.getAssetData());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, asset);
        }
        return ComUtil.response(Codes.ASSET_NOT_FOUNT, Messages.FAILED, null);
    }

    public Response getAsset(List<String> assetIds) {
        List<Asset> assets = new ArrayList<>();
        for (String assetId: assetIds) {
            AssetEntity assetEntity = assetRepository.findByAssetId(assetId);
            if (assetEntity != null) {
                Asset asset = new Asset();
                asset.setId(assetEntity.getAssetId());
                asset.setContentType(assetEntity.getAssetExtension());
                asset.setData(assetEntity.getAssetData());
                assets.add(asset);
            } else {
                assets.add(new Asset());
            }
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, assets);
    }
}
