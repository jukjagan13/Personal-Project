package com.ioe.entity;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "ioe_verification_codes")
@Data
public class VerificationCodesEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codeId;
    private String activity;
    private String session;
    private Integer code;
    private Integer noOfTries = 0;
    private Integer verified = 0;
    private Timestamp providedTs;
    private Timestamp expirationTs;
}
