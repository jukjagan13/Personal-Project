package com.ioe.model;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class Response<Object> {
    private String code;
    private String message;
    private Object data;

    public Response() {}

    public Response(String code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }
}
