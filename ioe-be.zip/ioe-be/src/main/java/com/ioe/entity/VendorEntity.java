package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_vendors")
@Data
public class VendorEntity {
    @Id
    private String vendorId;
    private String businessName;
    private String location;
    private String businessMobileNumber;
    private String businessEmailAddress;
    private String vendorStatus;
    private Integer isActive=0;
    private String createdTs;
}
