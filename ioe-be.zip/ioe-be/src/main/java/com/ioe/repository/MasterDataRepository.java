package com.ioe.repository;

import com.ioe.entity.MasterDataEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MasterDataRepository extends JpaRepository<MasterDataEntity, Integer> {

    List<MasterDataEntity> findAllByMasterDataTypeOrderByMasterDataOrderNo(String masDataType);

    MasterDataEntity findByMasterDataTypeAndMasterDataCode(String masDataType, String masterDataCode);

}
