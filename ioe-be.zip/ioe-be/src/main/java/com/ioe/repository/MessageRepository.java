package com.ioe.repository;

import com.ioe.entity.MessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<MessageEntity, String> {

    MessageEntity findByMessageId(String messageId);

    List<MessageEntity> findAllBySenderId(String senderId);

    List<MessageEntity> findAllBySenderIdAndReceiverType(String senderId, String receiverType);

    List<MessageEntity> findAllBySenderIdAndReceiverId(String senderId, String receiverId);

    List<MessageEntity> findAllByReceiverId(String receiverId);

    List<MessageEntity> findAllByReceiverIdAndIsRead(String receiverId, Integer isRead);

    List<MessageEntity> findAllByReceiverType(String receiverType);

    List<MessageEntity> findAllByReceiverIdAndReceiverType(String receiverId, String receiverType);

    @Query("SELECT COUNT(*) FROM MessageEntity WHERE receiverId = ?1 AND isRead = 0")
    Long fetchUnReadMessageCount(String id);
}
