package com.ioe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ioe.entity.MessageEntity;
import com.ioe.entity.UserEntity;
import com.ioe.model.Message;
import com.ioe.model.Response;
import com.ioe.model.User;
import com.ioe.repository.CodeGenerator;
import com.ioe.repository.MessageRepository;
import com.ioe.repository.UserRepository;
import com.ioe.repository.VendorRepository;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Constants;
import com.ioe.utils.Messages;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MessageService {
    @Autowired
    private User loggedInUser;

    @Autowired
    private CodeGenerator codeGenerator;
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private VendorRepository vendorRepository;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VendorsService vendorsService;

    public Response sendMessage(Message message) {
        ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setAmbiguityIgnored(true);
        MessageEntity newMessage = new MessageEntity();
        modelMapper.map(message, newMessage);
        newMessage.setIsRead(0);
        newMessage.setMessageId(codeGenerator.generateCode(Constants.CODE_MESSAGE, null));
        newMessage.setMessagedTs(new Timestamp(System.currentTimeMillis()).toString());
        if (loggedInUser.getUserType().equals(Constants.USER_TYPE_VENDOR)) {
            newMessage.setSenderType(Constants.USER_TYPE_VENDOR);
            newMessage.setReceiverType(Constants.USER_TYPE_ADMIN);
        } else if (loggedInUser.getUserType().equals(Constants.USER_TYPE_ADMIN)) {
            newMessage.setSenderType(Constants.USER_TYPE_ADMIN);
            newMessage.setReceiverType(Constants.USER_TYPE_VENDOR);
        }
        messageRepository.save(newMessage);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response markReadMessages(String senderId) {
        List<MessageEntity> messageEntities = new ArrayList<>();
        if (loggedInUser.getUserType().equals(Constants.USER_TYPE_ADMIN)) {
            messageEntities = messageRepository.findAllBySenderIdAndReceiverType(senderId, Constants.USER_TYPE_ADMIN);
        } else if (loggedInUser.getUserType().equals(Constants.USER_TYPE_VENDOR)) {
            messageEntities = messageRepository.findAllByReceiverIdAndReceiverType(loggedInUser.getUserId(), Constants.USER_TYPE_VENDOR);
        }
        messageEntities.forEach(m -> {
            m.setIsRead(1);
            messageRepository.save(m);
        });
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response getMessages(String senderId) {
        ModelMapper modelMapper = new ModelMapper();
        List<MessageEntity> messageEntities = new ArrayList<>();
        if (loggedInUser.getUserType().equals(Constants.USER_TYPE_ADMIN)) {
            messageEntities = messageRepository.findAllBySenderIdAndReceiverType(senderId, Constants.USER_TYPE_ADMIN);
            messageEntities.addAll(messageRepository.findAllBySenderIdAndReceiverId(loggedInUser.getUserId(), senderId));
        } else if (loggedInUser.getUserType().equals(Constants.USER_TYPE_VENDOR)) {
            messageEntities = messageRepository.findAllByReceiverIdAndReceiverType(loggedInUser.getUserId(), Constants.USER_TYPE_VENDOR);
            messageEntities.addAll(messageRepository.findAllBySenderIdAndReceiverType(loggedInUser.getUserId(), Constants.USER_TYPE_ADMIN));
        }
        List<Message> messages = modelMapper.map(messageEntities, new TypeToken<List<Message>>() {
        }.getType());
        Collections.sort(messages, Comparator.comparing(Message::getMessagedTs));
        return ComUtil.response(Codes.OK, Messages.SUCCESS, messages);
    }

    public Response getMessagesList() {
        ObjectMapper objectMapper = new ObjectMapper();
        if (loggedInUser.getUserType().equals(Constants.USER_TYPE_ADMIN)) {
            List<MessageEntity> messageEntities = messageRepository.findAllByReceiverType(Constants.USER_TYPE_ADMIN);
            Collections.sort(messageEntities, Comparator.comparing(MessageEntity::getIsRead));
            Map<String, List<MessageEntity>> messagedVendors = messageEntities.stream().collect(Collectors.groupingBy(MessageEntity::getSenderId));
            List<JsonNode> vendors = new ArrayList<>();
            Iterator<Map.Entry<String, List<MessageEntity>>> itr = messagedVendors.entrySet().iterator();
            while (itr.hasNext()) {
                Map<String, String> list = new HashMap<>();
                Map.Entry<String, List<MessageEntity>> v = itr.next();
                List<MessageEntity> messages = v.getValue();
                Collections.sort(messages, Comparator.comparing(MessageEntity::getMessagedTs));
                UserEntity userEntity = userRepository.findByUserId(v.getKey());
                List<MessageEntity> unReadMessages = messages.stream().filter(m -> m.getIsRead() == 0).collect(Collectors.toList());
                list.put("senderId", v.getKey());
                list.put("senderName", userEntity.getUsername());
                list.put("unread", String.valueOf(unReadMessages.size()));
                list.put("lastMessage", messages.get(messages.size() - 1).getMessageContent());
                vendors.add(objectMapper.convertValue(list, JsonNode.class));
            }
            Collections.sort(vendors, Comparator.comparing(v -> v.get("unread").asText()));
            return ComUtil.response(Codes.OK, Messages.SUCCESS, vendors);
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response getNotificationCount() {
        Long unReadMessage = messageRepository.fetchUnReadMessageCount(loggedInUser.getUserId());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, unReadMessage);
    }
}
