package com.ioe.utils;

public class Constants {
    //Codes
    public static final String CODE_USER = "user_code";
    public static final String CODE_VERIFICATION = "verification_code";
    public static final String CODE_SESSION = "session_id";
    public static final String CODE_VENDOR = "vendor_code";
    public static final String CODE_VENDOR_SERVICE = "vendor_service_code";
    public static final String CODE_MESSAGE = "message_code";
    public static final String CODE_ASSET = "asset_code";
    public static final String CODE_PROMOTION = "promotion_code";

    //Verification Activities
    public static final String VERIFICATION_ACTIVITY_SIGNUP = "SIGNUP";
    public static final String VERIFICATION_ACTIVITY_MFA = "MFA";
    public static final String VERIFICATION_ACTIVITY_FORGOT = "FORGOT";

    //User Types
    public static final String USER_TYPE_USER = "USER";
    public static final String USER_TYPE_VENDOR = "VENDOR";
    public static final String USER_TYPE_ADMIN = "ADMIN";

    //Vendor Status
    public static final String VENDOR_STATUS_CREATED = "CREATED";
    public static final String VENDOR_STATUS_PENDING = "PENDING";
    public static final String VENDOR_STATUS_APPROVED = "APPROVED";
    public static final String VENDOR_STATUS_REJECTED = "REJECTED";

    //Promotion Status
    public static final String PROMOTION_CREATED = "CREATED";
    public static final String PROMOTION_PENDING = "PENDING";
    public static final String PROMOTION_LIVE = "LIVE";
    public static final String PROMOTION_EXPIRED = "EXPIRED";

    //Notification Sent Medium
    public static final String MEDIUM_EMAIL = "EMAIL";
    public static final String MEDIUM_SMS = "SMS";

    //Asset Type
    public static final String ASSET_TYPE_USERLOGO = "USERLOGO";
    public static final String ASSET_TYPE_VENDORSERVICE = "VENDORSERVICE";
    public static final String ASSET_TYPE_VENDORLOGO = "VENDORLOGO";

    //Master Data Types
    public static final String MAS_DATA_TYPE_SERVICE = "service_type";

}
