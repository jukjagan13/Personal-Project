package com.ioe.model;

import lombok.Data;

@Data
public class User {
    private String userId;
    private String vendorId;
    private String username;
    private String userType;
    private String logoId;
    private String mobileNumber;
    private String emailAddress;
}
