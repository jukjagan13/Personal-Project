package com.ioe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ioe.entity.PromotionPlanEntity;
import com.ioe.entity.VendorServiceEntity;
import com.ioe.entity.VendorServicePromotionEntity;
import com.ioe.exception.SystemException;
import com.ioe.exception.ValidationError;
import com.ioe.exception.ValidationException;
import com.ioe.model.*;
import com.ioe.repository.CodeGenerator;
import com.ioe.repository.PromotionPlanRepository;
import com.ioe.repository.VendorServicePromotionRepository;
import com.ioe.repository.VendorServiceRepository;
import com.ioe.utils.*;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.security.SignatureException;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PromotionService {
    @Value("${razorpay.key-id:}")
    private String razorPayKeyId;
    @Value("${razorpay.key-secret:}")
    private String razorPayKeySecret;

    @Autowired
    @Qualifier("razorPay")
    private RestTemplate razorPayRestTemplate;

    @Autowired
    private CodeGenerator codeGenerator;
    @Autowired
    private PromotionPlanRepository promotionPlanRepository;
    @Autowired
    private VendorServicePromotionRepository vendorServicePromotionRepository;
    @Autowired
    private VendorServiceRepository vendorServiceRepository;

    public Response getPromotionPlans() {
        ModelMapper modelMapper = new ModelMapper();
        List<PromotionPlanEntity> promotionPlanEntities = promotionPlanRepository.findAll();
        List<PromotionPlan> promotionPlans = modelMapper.map(promotionPlanEntities, new TypeToken<List<PromotionPlan>>() {
        }.getType());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, promotionPlans);
    }

    public Response getPromotions(String vendorId) {
        ModelMapper modelMapper = new ModelMapper();
        List<VendorServicePromotionEntity> vendorServicePromotionEntities = vendorServicePromotionRepository.findAllByVendorId(vendorId);
        vendorServicePromotionEntities.forEach(p -> {
            if (p.getStatus().equals(Constants.PROMOTION_LIVE)) {
                if (p.getPromotionStartDate().before(new Date()) && p.getPromotionEndDate().after(new Date())) {
                    p.setStatus(Constants.PROMOTION_EXPIRED);
                    vendorServicePromotionRepository.save(p);
                }
            }
        });
        vendorServicePromotionEntities = vendorServicePromotionEntities.stream().filter(vp -> vp.getStatus().equals(Constants.PROMOTION_LIVE)).collect(Collectors.toList());
        List<VendorServicePromotion> vendorServicePromotions = modelMapper.map(vendorServicePromotionEntities, new TypeToken<List<VendorServicePromotion>>() {
        }.getType());
        return ComUtil.response(Codes.OK, Messages.SUCCESS, vendorServicePromotions);
    }

    public Response promoteServices(String vendorId, List<PromotionPayload> promotionPayload) {
        if (promotionPayload.size() > 0) {
            Map<String, String> result = new HashMap<>();
            Float totalAmount = new Float(0);
            for (PromotionPayload payload : promotionPayload) {
                PromotionPlanEntity promotionPlanEntity = promotionPlanRepository.findByPlanCode(payload.getPlanCode());
                Float planAmount = Float.sum(promotionPlanEntity.getPlanAmount(), promotionPlanEntity.getTaxAmount());
                totalAmount = Float.sum(totalAmount, planAmount);
            }
            String orderId = createOrder(totalAmount * 100);
            for (PromotionPayload payload : promotionPayload) {
                PromotionPlanEntity promotionPlanEntity = promotionPlanRepository.findByPlanCode(payload.getPlanCode());
                Calendar cal = Calendar.getInstance();
                Timestamp promotionStartDate = new Timestamp(cal.getTimeInMillis());
                cal.setTime(promotionStartDate);
                cal.add(Calendar.MONTH, promotionPlanEntity.getPlanDuration());
                cal.add(Calendar.SECOND, -1);
                Timestamp promotionEndDate = new Timestamp(cal.getTimeInMillis());

                VendorServicePromotionEntity newVendorServicePromotionEntity = new VendorServicePromotionEntity();
                newVendorServicePromotionEntity.setPromotionId(codeGenerator.generateCode(Constants.CODE_PROMOTION, null));
                newVendorServicePromotionEntity.setVendorId(vendorId);
                newVendorServicePromotionEntity.setServiceId(payload.getServiceId());
                newVendorServicePromotionEntity.setPlanCode(payload.getPlanCode());
                newVendorServicePromotionEntity.setStatus(Constants.PROMOTION_CREATED);
                newVendorServicePromotionEntity.setPromotionStartDate(promotionStartDate);
                newVendorServicePromotionEntity.setPromotionEndDate(promotionEndDate);
                newVendorServicePromotionEntity.setPlanAmount(promotionPlanEntity.getPlanAmount());
                newVendorServicePromotionEntity.setTaxAmount(promotionPlanEntity.getTaxAmount());
                newVendorServicePromotionEntity.setProviderOrderId(orderId);
                newVendorServicePromotionEntity.setCreatedTs(new Timestamp(System.currentTimeMillis()).toString());
                newVendorServicePromotionEntity.setLastUpdatedTs(new Timestamp(System.currentTimeMillis()).toString());

                vendorServicePromotionRepository.save(newVendorServicePromotionEntity);
            }
            result.put("keyId", razorPayKeyId);
            result.put("orderId", orderId);
            result.put("amount", totalAmount.toString());
            return ComUtil.response(Codes.OK, Messages.SUCCESS, result);
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response confirmServicePromotion(String vendorId, RazorPayConfirmation paymentConfirmation) {
        JsonNode paymentDetails = confirmPayment(paymentConfirmation);
        if (paymentDetails.has("id") && paymentConfirmation.getPaymentId().equals(paymentDetails.get("id").asText())) {
            List<VendorServicePromotionEntity> vendorServicePromotionEntities = vendorServicePromotionRepository.findAllByProviderOrderId(paymentConfirmation.getOrderId());
            vendorServicePromotionEntities.forEach(vs -> {
                if (paymentConfirmation.getSignature() != null && paymentConfirmation.getPaymentId() != null) {
                    vs.setProviderReferenceId(paymentConfirmation.getSignature());
                    vs.setProviderPaymentId(paymentConfirmation.getPaymentId());
                    vs.setStatus(Constants.PROMOTION_LIVE);
                    vendorServicePromotionRepository.save(vs);

                    VendorServiceEntity vendorServiceEntity = vendorServiceRepository.findByServiceId(vs.getServiceId());
                    vendorServiceEntity.setIsPromoted(1);
                    vendorServiceEntity.setPromotionDue(vs.getPromotionEndDate());
                    vendorServiceRepository.save(vendorServiceEntity);
                }
            });
            return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
        }
        return ComUtil.response(Codes.PAYMENT_FAILED, Messages.FAILED, null);
    }

    public String createOrder(Float amount) {
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("amount", amount);
        inputData.put("currency", "INR");
        inputData.put("payment_capture", 1);
        JsonNode subscriptionData = razorPayRestTemplate.postForObject("https://api.razorpay.com/v1/orders", inputData, JsonNode.class);
        if (subscriptionData.has("id")) {
            return subscriptionData.get("id").textValue();
        } else {
            throw new ValidationException(new ValidationError(Messages.FAILED, Messages.ORDER_CREATION_FAILED));
        }
    }

    public ObjectNode confirmPayment(RazorPayConfirmation razorPayConfirmation) {
//        HTML TEMPLATE TO COMPLETE PAYMENT
//        <html>
//        <body>
//        <form action="https://localhost:4200/v1/payment/success/" method="POST">
//        <script
//                        src="https://checkout.razorpay.com/v1/checkout.js"
//                data-key="rzp_test_DXXS7a5dasSBdy"
//                data-amount="20000.00"
//                data-currency="INR"
//                data-order_id="order_GIqdoPT5ESh07g"
//                data-buttontext="Pay with Razorpay"
//                data-name="Acme Corp"
//                data-description="A Wild Sheep Chase is the third novel by Japanese author Haruki Murakami"
//                data-image="https://example.com/your_logo.jpg"
//                data-prefill.name="Gaurav Kumar"
//                data-prefill.email="gaurav.kumar@example.com"
//                data-theme.color="#F37254"></script>
//        <input type="hidden" custom="Hidden Element" name="hidden">
//        </form>
//        </body>
//        </html>

        try {
            if (!CryptoUtil.calculateRFC2104HMAC(razorPayConfirmation.getOrderId() + "|" +
                    razorPayConfirmation.getPaymentId(), razorPayKeySecret).equals(razorPayConfirmation.getSignature())) {
                ValidationError validationError = new ValidationError();
                validationError.setDefaultMessage("Invalid signature");
                ValidationException validationException = new ValidationException();
                validationException.addValidationError(validationError);
                throw validationException;
            }
        } catch (SignatureException e) {
            throw new SystemException("Error validating payment signature", e);
        }

        //Get Subscription Details
        ObjectNode paymentData = razorPayRestTemplate.getForObject("https://api.razorpay.com/v1/payments/" + razorPayConfirmation.getPaymentId(), ObjectNode.class);
        return paymentData;
    }
}
