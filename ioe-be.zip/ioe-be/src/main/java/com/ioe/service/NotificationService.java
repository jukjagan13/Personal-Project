package com.ioe.service;

import com.ioe.entity.UserEntity;
import com.ioe.entity.VendorEntity;
import com.ioe.repository.UserRepository;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Constants;
import com.ioe.utils.Notifications;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.util.List;

@Component
@Slf4j
public class NotificationService {
    @Value("${app.ui-url:}")
    private String uiUrl;
    @Value("${app.aes-key:}")
    private String aesKey;
    @Value("${app.support-email:}")
    private String supportEmail;

    @Autowired
    private MessageSource emailContents;
    @Autowired
    private MessageSource urlContents;
    @Autowired
    private Notifications notifications;
    @Autowired
    private SpringTemplateEngine templateEngine;

    @Autowired
    private UserRepository userRepository;

    public void signUpVerificationMail(String email, String username, Integer otp) {
        try {
            String subject = ComUtil.content(emailContents, "SIGNUP_VERIFICATION_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "SIGNUP_VERIFICATION_EMAIL_BODY", new Object[]{username, otp.toString()});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void forgotPasswordMail(String email, String username, Integer otp) {
        try {
            String subject = ComUtil.content(emailContents, "FORGOT_PASSWORD_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "FORGOT_PASSWORD_EMAIL_BODY", new Object[]{username, otp.toString()});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void newVendorRequestMail(VendorEntity vendor) {
        try {

//        String encryptedId = CryptoUtil.aesEncrypt(vendor.getVendorId(), aesKey);
            String encryptedId = vendor.getVendorId();
            String approveRejectUrl = uiUrl + ComUtil.content(urlContents, "VENDOR_REQUEST_URL", new Object[]{encryptedId});
            String subject = ComUtil.content(emailContents, "VENDOR_REQUEST_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "VENDOR_REQUEST_EMAIL_BODY", new Object[]{
                    vendor.getVendorId(), vendor.getBusinessName(),
                    vendor.getLocation(), vendor.getBusinessMobileNumber(),
                    vendor.getBusinessEmailAddress(), approveRejectUrl});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);

            List<UserEntity> admins = userRepository.findByUserType(Constants.USER_TYPE_ADMIN);

            admins.forEach(admin -> notifications.sendEmail(admin.getEmailAddress(), subject, body));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void accountActivated(String email, String username) {
        try {
            String loginUrl = uiUrl + ComUtil.content(urlContents, "LOGIN_URL", new Object[]{});
            String subject = ComUtil.content(emailContents, "ACCOUNT_ACTIVATED_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "ACCOUNT_ACTIVATED_EMAIL_BODY", new Object[]{username, loginUrl});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void accountDeactivated(String email, String username) {
        try {
            String subject = ComUtil.content(emailContents, "ACCOUNT_DEACTIVATED_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "ACCOUNT_DEACTIVATED_EMAIL_BODY", new Object[]{username, supportEmail});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void vendorApproved(String email, String username) {
        try {
            String loginUrl = uiUrl + ComUtil.content(urlContents, "LOGIN_URL", new Object[]{});
            String subject = ComUtil.content(emailContents, "VENDOR_REQUEST_APPROVED_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "VENDOR_REQUEST_APPROVED_EMAIL_BODY", new Object[]{username, loginUrl});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void vendorRejected(String email, String username) {
        try {
            String subject = ComUtil.content(emailContents, "VENDOR_REQUEST_REJECTED_EMAIL_SUBJECT", new Object[]{});
            String content = ComUtil.content(emailContents, "VENDOR_REQUEST_REJECTED_EMAIL_BODY", new Object[]{username, supportEmail});
            Context context = new Context();
            context.setVariable("content", content);
            String body = templateEngine.process("email-base", context);
            notifications.sendEmail(email, subject, body);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
