package com.ioe.config;

import com.ioe.model.User;
import com.ioe.service.AuthService;
import lombok.var;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

@Configuration
public class CommonConfig {
    @Value("${app.mail.account.username:}")
    private String mailAccUsername;
    @Value("${app.mail.account.password:}")
    private String mailAccPassword;
    @Value("${razorpay.key-id:}")
    private String razorPayKeyId;
    @Value("${razorpay.key-secret:}")
    private String razorPayKeySecret;

    @Autowired
    private AuthService authService;

    @Bean
    public JavaMailSender mailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost("mail.inscriptoccasionsandevents.com");
        mailSender.setPort(587);
        mailSender.setUsername(mailAccUsername);
        mailSender.setPassword(mailAccPassword);
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.debug", "true");
        return mailSender;
    }

    @Bean
    public ResourceBundleMessageSource emailContents() {
        var source = new ResourceBundleMessageSource();
        source.setBasenames("contents/emailContents");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean
    public ResourceBundleMessageSource urlContents() {
        var source = new ResourceBundleMessageSource();
        source.setBasenames("contents/urlContents");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean
    @Scope(value = BeanDefinition.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public User loggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = new User();
        if (authentication != null && !authentication.getName().equals("anonymousUser")) {
            user = authService.getUserInfo(authentication.getName());
        }
        if (user.getUserId() == null) {
            user = new User();
            user.setUserId(null);
            user.setUsername("Anonymous");
        }
        return user;
    }

    @Bean
    @Scope(value = BeanDefinition.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS)
    @Qualifier("razorPay")
    public RestTemplate razorPayRestTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getInterceptors().add(new ClientHttpRequestInterceptor() {
            @Override
            public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
                    throws IOException {

                String plainCreds = razorPayKeyId + ":" + razorPayKeySecret;
                byte[] plainCredsBytes = plainCreds.getBytes();
                byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
                String base64Creds = new String(base64CredsBytes);
                request.getHeaders().add("Authorization", "Basic " + base64Creds);
                return execution.execute(request, body);
            }
        });
        return restTemplate;
    }
}
