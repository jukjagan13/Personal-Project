package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_app_faqs")
@Data
public class FAQEntity {
    @Id
    private Integer faqId;
    private String appSection;
    private String faqQuestion;
    private String faqAnswer;
}
