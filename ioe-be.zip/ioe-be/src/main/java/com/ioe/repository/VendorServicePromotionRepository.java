package com.ioe.repository;

import com.ioe.entity.VendorServicePromotionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorServicePromotionRepository extends JpaRepository<VendorServicePromotionEntity, String> {

    VendorServicePromotionEntity findByPromotionId(String promotionId);

    List<VendorServicePromotionEntity> findAllByVendorId(String vendorId);

    List<VendorServicePromotionEntity> findAllByProviderOrderId(String orderId);

    List<VendorServicePromotionEntity> findAllByServiceId(String serviceId);

    List<VendorServicePromotionEntity> findAllByVendorIdAndStatus(String vendorId, String status);

    List<VendorServicePromotionEntity> findAllByVendorIdAndStatusNot(String vendorId, String status);

    List<VendorServicePromotionEntity> findAllByServiceIdAndStatus(String serviceId, String status);

    List<VendorServicePromotionEntity> findAllByServiceIdAndStatusNot(String serviceId, String status);

}
