package com.ioe.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SubscriptionPlan {

    private String planCode;
    private String planName;
    private String planId;
    private Float amount;
    private Float taxAmount;
    private Float subTotal;


}
