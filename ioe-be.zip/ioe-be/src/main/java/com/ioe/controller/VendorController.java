package com.ioe.controller;

import com.ioe.model.Response;
import com.ioe.model.Vendor;
import com.ioe.model.VendorService;
import com.ioe.service.VendorsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("vendor")
@Slf4j
public class VendorController {
    @Autowired
    private VendorsService vendorsService;

    @GetMapping("all")
    public Response getVendors(@RequestParam(name = "is_active", required = false) Boolean isActive, @RequestParam(name = "with_service", required = false) Boolean withService) {
        return vendorsService.getVendors(isActive, withService);
    }

    @PostMapping("new")
    public Response addVendor(@RequestBody Vendor vendor) {
        return vendorsService.createVendor(vendor);
    }

    @GetMapping("{vendorId}")
    public Response getVendor(@PathVariable String vendorId, @RequestParam(name = "ignore_status", required = false) Boolean ignoreStatus) {
        return vendorsService.getVendor(vendorId, ignoreStatus);
    }

    @PostMapping("{vendorId}/activate")
    public Response activateVendor(@PathVariable String vendorId) {
        return vendorsService.activateVendor(vendorId);
    }

    @PostMapping("{vendorId}/deactivate")
    public Response deActivateVendor(@PathVariable String vendorId) {
        return vendorsService.deActivateVendor(vendorId);
    }

    @PostMapping("{vendorId}/approve")
    public Response approveVendor(@PathVariable String vendorId) {
        return vendorsService.approveVendor(vendorId);
    }

    @PostMapping("{vendorId}/reject")
    public Response rejectVendor(@PathVariable String vendorId) {
        return vendorsService.rejectVendor(vendorId);
    }

    @PostMapping("{vendorId}/service/add")
    public Response addVendorServices(@PathVariable String vendorId, @RequestBody VendorService vendorService) {
        return vendorsService.addVendorService(vendorId, vendorService);
    }

    @GetMapping("{vendorId}/services")
    public Response getVendorServices(@PathVariable String vendorId) {
        return vendorsService.getVendorServices(vendorId);
    }

    @GetMapping("{vendorId}/service/{serviceId}/info")
    public Response getVendorService(@PathVariable String vendorId, @PathVariable String serviceId) {
        return vendorsService.getVendorService(vendorId, serviceId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/delete")
    public Response deleteVendorService(@PathVariable String vendorId, @PathVariable String serviceId) {
        return vendorsService.deleteVendorService(serviceId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/publish")
    public Response publishVendorService(@PathVariable String vendorId, @PathVariable String serviceId) {
        return vendorsService.publishVendorService(serviceId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/unpublish")
    public Response unPublishVendorService(@PathVariable String vendorId, @PathVariable String serviceId) {
        return vendorsService.unPublishVendorService(serviceId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/logo")
    public Response setServiceLogo(@PathVariable String vendorId, @PathVariable String serviceId, @RequestBody String logo) {
        return vendorsService.setServiceLogo(vendorId, serviceId, logo);
    }

    @PostMapping("{vendorId}/service/{serviceId}/images")
    public Response addServiceImages(@PathVariable String vendorId, @PathVariable String serviceId, @RequestBody List<String> images) {
        return vendorsService.addServiceImages(vendorId, serviceId, images);
    }

    @GetMapping("{vendorId}/service/{serviceId}/images")
    public Response getServiceImages(@PathVariable String vendorId, @PathVariable String serviceId, @RequestParam(name = "limit", required = false) Integer limit) {
        return vendorsService.getServiceImages(vendorId, serviceId, limit);
    }

    @GetMapping("{vendorId}/service/{serviceId}/images/{imageId}")
    public Response getServiceImage(@PathVariable String vendorId, @PathVariable String serviceId, @PathVariable String imageId, @RequestParam(name = "limit", required = false) Integer limit) {
        return vendorsService.getServiceImages(vendorId, serviceId, imageId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/images/{imageId}/delete")
    public Response deleteServiceImage(@PathVariable String vendorId, @PathVariable String serviceId, @PathVariable String imageId) {
        return vendorsService.deleteServiceImage(vendorId, serviceId, imageId);
    }

    @PostMapping("{vendorId}/service/{serviceId}/images/delete")
    public void deleteServiceImages(@PathVariable String vendorId, @PathVariable String serviceId, @RequestBody List<String> imageIds) {
        for(String imageId: imageIds) {
            vendorsService.deleteServiceImage(vendorId, serviceId, imageId);
        }
    }
}
