package com.ioe.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
@Slf4j
public class ServiceInterceptor implements HandlerInterceptor {

//    @Autowired
//    private UserSessionRepository userSessionRepository;

//    @Autowired
//    @Qualifier("amcConfig")
//    private JsonNode amcConfigMap;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        //deriving and enabling Concurrent Session based on deployment configuration value;
//        boolean allowConcurrentSession = amcConfigMap.get("allow_concurrent_session").asBoolean();
//        if (!allowConcurrentSession) {
//            String sessionId = request.getHeader("Authorization");
//            if (sessionId != null) {
//                sessionId = sessionId.replace("Bearer ", "");
//                UserSessions userSession = userSessionRepository.findBySessionIdAndIsActiveSession(sessionId, 1);
//                if (userSession != null)
//                    return true;
//                throw new ValidationException(new ValidationError("You are already logged in.", "concurrentLogin"));
//            }
//        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception exception) throws Exception {
        long startTime = Long.valueOf(MDC.get("api-start-time"));
        log.info("Time taken for API {} is  {} ms", request.getRequestURI(), (System.currentTimeMillis() - startTime));
    }
}