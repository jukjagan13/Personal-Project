package com.ioe.repository;

import com.ioe.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.sql.Types;

@Component
public class AppDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private User loggedInUser;

    public void postUserReview(String name, String email, String review) {
        jdbcTemplate.update("INSERT INTO ioe_user_reviews (reviewer_name, reviewer_email, review_content, review_ts) " +
                "VALUES (?, ?, ?, current_timestamp)", name, email, review);
    }

    public void postUserView(String serviceId) {
        jdbcTemplate.update("INSERT INTO ioe_user_viewed (user_id, service_id, session_id, viewed_ts) " +
                "VALUES (?, ?, ?, current_timestamp)", loggedInUser.getUserId(), serviceId, SecurityContextHolder.getContext().getAuthentication().getPrincipal());
    }
}
