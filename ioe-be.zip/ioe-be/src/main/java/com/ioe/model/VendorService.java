package com.ioe.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;

@Data
public class VendorService {
    private String serviceId;
    private String vendorId;
    private String serviceType;
    private String serviceName;
    private JsonNode address;
    private String branchLocation;
    private String mobileNumber;
    private String serviceLogoId;
    private Asset serviceLogo;
    private JsonNode attributes;
    private JsonNode socialMediaLinks;
    private String aboutUs;
    private Integer isPublished;
    private Integer isPromoted;
    private String promotionDue;
}
