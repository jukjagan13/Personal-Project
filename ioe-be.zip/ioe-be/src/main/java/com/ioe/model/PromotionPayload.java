package com.ioe.model;

import lombok.Data;

@Data
public class PromotionPayload {
    private String serviceId;
    private String planCode;
}
