package com.ioe.repository;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ioe.entity.*;
import com.ioe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.xml.bind.DatatypeConverter;
import java.sql.Timestamp;
import java.util.UUID;

@Component
@Slf4j
public class CodeGenerator {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VerificationCodesRepository verificationCodesRepository;
    @Autowired
    private VendorRepository vendorRepository;
    @Autowired
    private VendorServiceRepository vendorServiceRepository;
    @Autowired
    private MessageRepository messageRepository;
    @Autowired
    private AssetRepository assetRepository;
    @Autowired
    private VendorServicePromotionRepository vendorServicePromotionRepository;

    public String generateCode(String codeType, JsonNode addlProp) {
        ObjectMapper objectMapper = new ObjectMapper();
        boolean generated = false;
        while (!generated) {
            String generatedCode = UUID.randomUUID().toString();
            if (codeType.equalsIgnoreCase(Constants.CODE_USER)) {
                UserEntity existingUser = userRepository.findByUserId(generatedCode);
                if (existingUser == null) {
                    return generatedCode;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_VERIFICATION)) {
                return RandomStringUtils.randomNumeric(8);
            } else if (codeType.equalsIgnoreCase(Constants.CODE_ASSET)) {
                AssetEntity existingAsset = assetRepository.findByAssetId(generatedCode);
                if(existingAsset == null) {
                    return generatedCode;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_SESSION)) {
                ObjectNode sessionData = objectMapper.createObjectNode();
                String userId = addlProp.has("userId") ? addlProp.get("userId").asText() : null;
                sessionData.put("ts", new Timestamp(System.currentTimeMillis()).toString());
                sessionData.put("id", userId);
                String data = "";
                try {
                    data = objectMapper.writeValueAsString(sessionData);
                } catch (Exception e) {
                    e.printStackTrace();
                }
//                String sessionId = Base64.getEncoder().encode(data.getBytes()).toString();
                String sessionId = DatatypeConverter.printBase64Binary(data.getBytes());
                VerificationCodesEntity existingVerification = verificationCodesRepository.findBySession(sessionId);
                if (existingVerification == null) {
                    return sessionId;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_VENDOR)) {
                generatedCode = generatedCode + "-" + RandomStringUtils.randomNumeric(4);
                VendorEntity existingVendor = vendorRepository.findByVendorId(generatedCode);
                if (existingVendor == null) {
                    return generatedCode;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_VENDOR_SERVICE)) {
                generatedCode = generatedCode + "-" + RandomStringUtils.randomNumeric(4) + "-" + RandomStringUtils.randomAlphanumeric(8);
                VendorServiceEntity existingService = vendorServiceRepository.findByServiceId(generatedCode);
                if (existingService == null) {
                    return generatedCode;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_MESSAGE)) {
                MessageEntity existingMessage = messageRepository.findByMessageId(generatedCode);
                if (existingMessage == null) {
                    return generatedCode;
                }
            } else if (codeType.equalsIgnoreCase(Constants.CODE_PROMOTION)) {
                VendorServicePromotionEntity vendorServicePromotionEntity = vendorServicePromotionRepository.findByPromotionId(generatedCode);
                if (vendorServicePromotionEntity == null) {
                    return generatedCode;
                }
            }
        }
        return null;
    }
}
