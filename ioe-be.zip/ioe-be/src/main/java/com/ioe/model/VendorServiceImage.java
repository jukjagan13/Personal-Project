package com.ioe.model;

import lombok.Data;

@Data
public class VendorServiceImage {
    private String vendorImageId;
    private Asset imageData;
    private String uploadedTs;
}
