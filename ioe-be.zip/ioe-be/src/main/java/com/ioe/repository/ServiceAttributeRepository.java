package com.ioe.repository;

import com.ioe.entity.ServiceAttributesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceAttributeRepository extends JpaRepository<ServiceAttributesEntity, Integer> {

    List<ServiceAttributesEntity> findAllByServiceType(String serviceType);

}
