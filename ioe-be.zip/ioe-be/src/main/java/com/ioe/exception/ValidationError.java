package com.ioe.exception;

import lombok.Data;

@Data
public class ValidationError {
    public ValidationError() {
    }

    public ValidationError(String objectName, String defaultMessage) {
        this.objectName = objectName;
        this.defaultMessage = defaultMessage;
    }

    public ValidationError(String objectName, String defaultMessage, String code) {
        this.objectName = objectName;
        this.defaultMessage = defaultMessage;
        this.code = code;
    }

    private String defaultMessage;
    private String objectName;
    private String field;
    private String rejectedValue;
    private String code;
}