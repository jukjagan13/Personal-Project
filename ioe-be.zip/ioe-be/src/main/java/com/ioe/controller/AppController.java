package com.ioe.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.ioe.entity.UserEntity;
import com.ioe.model.PromotionPayload;
import com.ioe.model.RazorPayConfirmation;
import com.ioe.model.Response;
import com.ioe.model.UserReview;
import com.ioe.repository.UserRepository;
import com.ioe.repository.VendorRepository;
import com.ioe.service.*;
import com.ioe.utils.CryptoUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("app")
@Slf4j
public class AppController {
    @Autowired
    private VendorsService vendorsService;
    @Autowired
    private AppService appService;
    @Autowired
    private AssetService assetService;
    @Autowired
    private PromotionService promotionService;

    @PostMapping(value = "services")
    public Response getServices(@RequestBody List<String> serviceTypes, @RequestParam(name = "keyword", required = false) String keyword, @RequestParam(name = "location", required = false) String location, @RequestParam(name = "shuffle", required = false) Boolean shuffle, @RequestParam(name = "promoted", required = false) Boolean promoted, @RequestParam(name = "limit", required = false) Integer limit) {
        return vendorsService.getServices(keyword, serviceTypes, location, shuffle, promoted, limit);
    }

    @PostMapping(value = "services/basic")
    public Response getServicesBasicDetails(@RequestBody List<String> serviceTypes, @RequestParam(name = "keyword", required = false) String keyword, @RequestParam(name = "location", required = false) String location, @RequestParam(name = "shuffle", required = false) Boolean shuffle, @RequestParam(name = "promoted", required = false) Boolean promoted, @RequestParam(name = "limit", required = false) Integer limit) {
        return vendorsService.getServicesBasic(keyword, serviceTypes, location, shuffle, promoted, limit);
    }

    @PostMapping(value = "service/{serviceId}/view")
    public Response viewService(@PathVariable String serviceId) {
        return appService.viewVendorService(serviceId);
    }

    @GetMapping(value = "recently-viewed")
    public Response recentlyViewedServices(@RequestParam(name = "limit", required = false) Integer limit) {
        return appService.recentlyViewedServices(limit);
    }

    @PostMapping(value = "services/featured/logos")
    public Response getFeaturedServicesLogos(@RequestBody List<String> serviceTypes, @RequestParam(name = "limit", required = false) Integer limit) {
        return vendorsService.getFeaturedServicesLogo(serviceTypes, limit);
    }

    @PostMapping(value = "faq")
    public Response getFAQs(@RequestBody String appSection, @RequestParam(name = "shuffle", required = false) Boolean shuffle) {
        return appService.getFAQs(appSection, shuffle);
    }

    @PostMapping(value = "review")
    public Response submitUserReview(@RequestBody UserReview userReview) {
//        return appService.submitUserReview(name, email, review);
        return appService.submitUserReview(userReview.getName(), userReview.getEmail(), userReview.getReview());
    }

    @PostMapping(value = "asset")
    public Response getAssets(@RequestBody List<String> assetIds) {
        return assetService.getAsset(assetIds);
    }

    @GetMapping(value = "asset/{assetId}")
    public Response getAsset(@PathVariable String assetId) {
        return assetService.getAsset(assetId);
    }

    @PostMapping("{vendorId}/promote")
    public Response promoteVendorServices(@PathVariable String vendorId, @RequestBody List<PromotionPayload> payload) {
        return promotionService.promoteServices(vendorId, payload);
    }

    @PostMapping("{vendorId}/promote/confirm")
    public Response confirmVendorServicesPromotion(@PathVariable String vendorId, @RequestBody RazorPayConfirmation razorPayConfirmation) {
        return promotionService.confirmServicePromotion(vendorId, razorPayConfirmation);
    }













    //Fixme: Test method

    @PostMapping("generateKey")
    public String generateKey() {
        return CryptoUtil.generateAESKey();
    }

    @Autowired
    VendorRepository vendorRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    NotificationService notificationService;
    @PostMapping("testNotification")
    public void testNotification() {
//        notificationService.newVendorRequestMail(vendorRepository.findAll().get(0));
        UserEntity user = userRepository.findByEmailAddress("JOHNJAGAN13@GMAIL.COM");
        notificationService.vendorApproved(user.getEmailAddress(), user.getUsername());
        notificationService.vendorRejected(user.getEmailAddress(), user.getUsername());
        notificationService.accountActivated(user.getEmailAddress(), user.getUsername());
        notificationService.accountDeactivated(user.getEmailAddress(), user.getUsername());
    }

    @RequestMapping(value = "payment/success", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public void testPayment(@RequestBody MultiValueMap<String, String> formParameters) {
        String orderId = formParameters.containsKey("razorpay_order_id") ? formParameters.get("razorpay_order_id").get(0) : null;
        String paymentId = formParameters.containsKey("razorpay_payment_id") ? formParameters.get("razorpay_payment_id").get(0) : null;
        String signature = formParameters.containsKey("razorpay_signature") ? formParameters.get("razorpay_signature").get(0) : null;
        RazorPayConfirmation razorPayConfirmation = new RazorPayConfirmation(paymentId, orderId, signature);
        promotionService.confirmServicePromotion("055c96c7-bbb0-4092-8ddf-b3096ff80e7c9467", razorPayConfirmation);
    }
}
