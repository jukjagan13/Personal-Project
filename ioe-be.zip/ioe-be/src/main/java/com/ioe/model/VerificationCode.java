package com.ioe.model;

import lombok.Data;

@Data
public class VerificationCode {
    private String destination;
    private String medium;
    private String session;
}
