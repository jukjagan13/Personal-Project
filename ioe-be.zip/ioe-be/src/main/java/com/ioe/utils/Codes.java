package com.ioe.utils;

public class Codes {
    //Generic Codes
    public static final String OK = "200";
    public static final String INTERNAL_SERVER_ERROR = "500";
    public static final String NOT_AUTHORIZED = "403";
    public static final String UNAUTHORIZED = "401";
    public static final String EXPIRED = "501";
    //Custom Codes

    //User Auth Codes
    public static final String USER_NOT_FOUND = "600";
    public static final String PASSWORD_MISMATCH = "601";
    public static final String USER_NOT_VERIFIED = "602";
    public static final String USER_EXIST = "603";
    public static final String USER_DEACTIVATED = "604";
    public static final String WRONG_OTP = "605";

    public static final String VENDOR_NOT_FOUND = "620";
    public static final String VENDOR_DEACTIVATED = "621";
    public static final String VENDOR_NOT_APPROVED = "622";

    public static final String SERVICE_NOT_FOUND = "630";
    public static final String SERVICE_DELETED = "631";
    public static final String SERVICE_NOT_PUBLISHED = "632";

    public static final String PROMOTION_EXPIRED = "640";
    public static final String PROMOTION_NOT_ACTIVE = "641";
    public static final String PAYMENT_FAILED = "642";

    public static final String ASSET_NOT_FOUNT = "700";
    public static final String ASSET_DELETED = "701";
}