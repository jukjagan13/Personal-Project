package com.ioe.repository;

import com.ioe.entity.VendorEntity;
import com.ioe.entity.VendorServiceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorServiceRepository extends JpaRepository<VendorServiceEntity, String> {

    List<VendorServiceEntity> findByVendorId(String vendorId);

    VendorServiceEntity findByServiceId(String serviceId);

    @Query(value = "FROM VendorServiceEntity where serviceId in (:serviceIds)")
    List<VendorServiceEntity> findAllByServiceIds(List<String> serviceIds);

    List<VendorServiceEntity> findAllByServiceType(String serviceType);

    @Query("from VendorServiceEntity where service_type = ?2 and service_name like %?1%")
    List<VendorServiceEntity> findAllByServiceNameAndServiceType(String serviceName, String serviceType);

    @Query("from VendorServiceEntity where service_type = ?2 and (service_name like %?1% or about_us like %?1%) and upper(service_address) like %?3%")
    List<VendorServiceEntity> findAllByServiceNameAndServiceTypeAndLocation(String serviceName, String serviceType, String branchLocation);
}