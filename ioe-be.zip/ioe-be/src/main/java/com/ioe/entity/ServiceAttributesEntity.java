package com.ioe.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_master_service_attributes")
@Data
public class ServiceAttributesEntity {
    @Id
    private Integer imsattrId;
    private String serviceType;
    private String attributeDataType;
    private String attributeDesc;
    private String attributeUnit;
    @Column(name = "default_value")
    private String attributeValue;
    private Integer attributeOrder;
    private Integer isOptional;
    private Integer isHighlighted;
}
