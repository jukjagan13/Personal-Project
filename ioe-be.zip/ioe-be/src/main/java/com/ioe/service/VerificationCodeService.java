package com.ioe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ioe.entity.VerificationCodesEntity;
import com.ioe.model.VerificationResult;
import com.ioe.repository.CodeGenerator;
import com.ioe.repository.VerificationCodesRepository;
import com.ioe.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Base64;

@Service
@Slf4j
public class VerificationCodeService {
    private static final Integer SESSION_EXPIRATION = 180000; //In milliseconds

    @Autowired
    private VerificationCodesRepository verificationCodesRepository;
    @Autowired
    private CodeGenerator codeGenerator;

    public VerificationCodesEntity generate(String activity, String userId) {
        VerificationCodesEntity v = new VerificationCodesEntity();
        v.setActivity(activity);
        v.setCode(Integer.parseInt(codeGenerator.generateCode(Constants.CODE_VERIFICATION, null)));
        ObjectNode userDetails = new ObjectMapper().createObjectNode();
        userDetails.put("userId", userId);
        v.setSession(codeGenerator.generateCode(Constants.CODE_SESSION, userDetails));
        v.setProvidedTs(new Timestamp(System.currentTimeMillis()));
        v.setExpirationTs(new Timestamp(System.currentTimeMillis() + SESSION_EXPIRATION));
        verificationCodesRepository.save(v);
        return v;
    }

    public VerificationResult verify(String sessionId, Integer code) {
        VerificationResult verificationResult = new VerificationResult();
        VerificationCodesEntity v = verificationCodesRepository.findBySession(sessionId);
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        if (v.getProvidedTs().compareTo(currentTimestamp) == -1 && (v.getExpirationTs().compareTo(currentTimestamp) == 0 || v.getExpirationTs().compareTo(currentTimestamp) == 1)) {
            if (v.getCode().equals(code)) {
                v.setVerified(1);
                verificationCodesRepository.save(v);
                verificationResult.setMatched(true);
            } else {
                v.setNoOfTries(v.getNoOfTries() + 1);
                verificationCodesRepository.save(v);
                verificationResult.setMisMatched(true);
            }
        } else {
            verificationResult.setExpired(true);
        }
        verificationResult.setNoOfTries(v.getNoOfTries());
        return verificationResult;
    }

    public JsonNode getSessionData(String sessionId) {
        String decoded = new String(Base64.getDecoder().decode(sessionId));
        JsonNode sessionData = null;
        try {
            sessionData = new ObjectMapper().readTree(decoded);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sessionData;
    }
}
