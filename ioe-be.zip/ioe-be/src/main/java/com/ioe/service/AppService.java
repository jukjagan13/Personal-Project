package com.ioe.service;

import com.ioe.entity.FAQEntity;
import com.ioe.entity.UserViewEntity;
import com.ioe.model.*;
import com.ioe.repository.AppDAO;
import com.ioe.repository.FAQRepository;
import com.ioe.repository.UserViewRepository;
import com.ioe.utils.Codes;
import com.ioe.utils.ComUtil;
import com.ioe.utils.Messages;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AppService {
    @Autowired
    private User loggedInUser;

    @Autowired
    private FAQRepository faqRepository;
    @Autowired
    private AppDAO appDAO;
    @Autowired
    private UserViewRepository userViewRepository;

    @Autowired
    private VendorsService vendorsService;

    public Response getFAQs(String appSection, Boolean shuffle) {
        ModelMapper modelMapper = new ModelMapper();
        List<FAQEntity> faqEntities = faqRepository.findAllByAppSection(appSection);
        List<FAQ> faqs = modelMapper.map(faqEntities, new TypeToken<List<FAQ>>(){}.getType());
        if(shuffle != null && shuffle)
            Collections.shuffle(faqs);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, faqs);
    }

    public Response submitUserReview(String name, String email, String review) {
        appDAO.postUserReview(name, email, review);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response viewVendorService(String serviceId) {
        appDAO.postUserView(serviceId);
        return ComUtil.response(Codes.OK, Messages.SUCCESS, null);
    }

    public Response recentlyViewedServices(Integer limit) {
        Map<String, List<VendorService>> recentlyViewedServices = new HashMap<>();
        if(limit == null)
            limit = 10;
        List<UserViewEntity> userViewEntities = userViewRepository.findAllByUserIdOrderByViewedTsDesc(loggedInUser.getUserId());
        List<String> viewedServiceTypes = userViewEntities.stream().filter(ComUtil.distinctByKey(UserViewEntity::getServiceType)).map(UserViewEntity::getServiceType).collect(Collectors.toList());
        for (String serviceType: viewedServiceTypes) {
            List<String> serviceIds = userViewEntities.stream().filter(uve -> uve.getServiceType().equalsIgnoreCase(serviceType)).limit(10).map(UserViewEntity::getServiceId).collect(Collectors.toList());
            List<VendorService> services = (List<VendorService>) vendorsService.getVendorServices(serviceIds).getData();
            recentlyViewedServices.put(serviceType, services);
        }
        return ComUtil.response(Codes.OK, Messages.SUCCESS, recentlyViewedServices);
    }
}
