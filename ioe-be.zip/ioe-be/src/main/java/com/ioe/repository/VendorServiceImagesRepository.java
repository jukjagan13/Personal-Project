package com.ioe.repository;

import com.ioe.entity.VendorServiceImagesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorServiceImagesRepository extends JpaRepository<VendorServiceImagesEntity, Integer> {

    List<VendorServiceImagesEntity> findAllByVendorServiceId(String serviceId);

    VendorServiceImagesEntity findAllByVendorServiceIdAndVendorImageId(String serviceId, String imageId);

    VendorServiceImagesEntity findAllByVendorServiceIdAndVendorImageIdAndIsDeleted(String serviceId, String imageId, Integer isDeleted);

    List<VendorServiceImagesEntity> findAllByVendorServiceIdAndIsDeleted(String serviceId, Integer isDeleted);

}
