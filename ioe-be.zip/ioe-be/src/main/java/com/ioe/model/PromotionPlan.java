package com.ioe.model;

import lombok.Data;

@Data
public class PromotionPlan {
    private String planCode;
    private String planName;
    private Float planAmount;
    private Float taxAmount;
    private Integer planDuration;
}
