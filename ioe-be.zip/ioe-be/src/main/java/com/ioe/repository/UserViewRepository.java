package com.ioe.repository;

import com.ioe.entity.UserViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserViewRepository extends JpaRepository<UserViewEntity, Integer> {

    List<UserViewEntity> findAllByUserId(String userId);

    List<UserViewEntity> findAllByUserIdOrderByViewedTsDesc(String userId);

}
