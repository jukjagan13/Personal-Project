package com.ioe.model;

import lombok.Data;

@Data
public class VerificationResult {
    private boolean expired;
    private boolean misMatched;
    private boolean matched;
    private Integer noOfTries;
}
