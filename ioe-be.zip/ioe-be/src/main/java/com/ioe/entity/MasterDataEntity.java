package com.ioe.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ioe_master_data")
@Data
public class MasterDataEntity {
    @Id
    private Integer masterDataId;
    private String masterDataType;
    private String masterDataCode;
    private String masterDataDesc;
    private Integer masterDataOrderNo;
}
